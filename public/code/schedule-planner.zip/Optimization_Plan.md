# Optimization Plan（已执行版）

## 1. 本质问题（系统级）
1. 协议层脆弱：LLM 经常输出非协议 JSON（例如 ```），导致解析和执行链路中断。
2. 语义到执行断层："前/后/依赖"语义在进入执行器前没有稳定收敛为可验证的动作约束。
3. 时间线编译缺失：动作在预览前只做“发现冲突”，缺少“编译为无冲突动作”的统一步骤。

## 2. 本轮优化目标
1. 不扩 prompt、不写死业务规则。
2. 通过系统层编译/校验/执行闭环提升鲁棒性。
3. 保证预览动作与确认执行动作一致，减少分支漂移。

## 3. 已实施改造
### P0：协议与动作编译层
1. `service/command_pipeline.py`
- 保持 agent-first，失败时受控 fallback。
- 严格无跨轮历史注入（每轮只靠工具查库补信息）。

2. `logic/graph_solver.py`
- 给每个动作补充 `source_node_id`，用于后续依赖链编译。

3. `service/app_service.py`
- 新增动作时间编译层 `_compile_actions_for_execution(...)`，在预校验前统一收敛动作：
  - 规范 insert/plan/update 的时间锚点。
  - 将依赖下界（`depends_on` + `resolved_parent_id`）转为时间下界。
  - 对冲突时段自动寻找下一个可执行空档。
  - 对本轮会被 update 的任务，先移除其旧占位，避免编译过度保守。
- 编译后再进入 `_prevalidate_actions` 与预览/执行链路，保证“预览可执行”。

### P1：执行器闭环与一致性
1. 已保留统一执行器（`service/action_executor.py` + `service/action_state_machine.py`）：
- `pre-validate -> execute -> post-verify -> rollback`
2. `PendingPlan` 执行统一走 `actions`，并保留 `updates` 兼容层。
3. 幂等、防重复提交、作用域快照回滚、目标态验收继续生效。

### P1：写路径收敛
1. 规划意图（`plan`）默认先预览再确认，不提前写库。
2. 预览与确认使用同一份结构化动作工件，减少“预览正确、执行跑偏”。

## 4. 测试结果
- 新增回归测试：`tests/test_action_timeline_compiler.py`
  - 冲突显式时间自动重排。
  - 前置动作重排后，后续依赖 update 自动顺延。
- 补齐遗留 TODO：`logic/graph_solver.py` 中 update 无显式时间时，现已继承目标任务原时间窗口（并有回归断言）。
- 全量测试：`67 passed`。

## 5. 当前架构结论
系统已从“LLM 文本驱动写库”切换为“协议动作驱动写库”：
1. LLM 负责提出候选动作。
2. 系统编译器负责把候选动作收敛为可执行动作。
3. 执行器负责事务化执行与后验验证。
4. 验收器负责目标态一致性校验。

这套结构比在 prompt 中堆规则更稳，也更不容易过拟合单一案例。
