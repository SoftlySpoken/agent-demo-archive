# Agent 系统架构与流程梳理（论文插图版）

本文档基于当前代码实现整理 Agent 相关全链路，目标是直接支撑科研论文插图绘制。

## 1. 目标与边界

- 关注范围：`app.py`、`service/*`、`ai/*`、`logic/*`、`db/*` 中与 Agent 解析、计划生成、执行、回滚、验收相关的主路径。
- 当前系统是“单轮无记忆”策略：每轮请求不传历史对话，缺失信息通过工具实时查库补齐。
- 当前默认模式是 `agent-first`，并带有 critic、trust gate、执行后验与回滚闭环。

## 2. 架构总览（可作为论文 Figure 1）

```mermaid
flowchart TD
    UI["UI Layer\napp.py"] --> SVC["Orchestration Layer\nservice/app_service.py"]
    SVC --> PIPE["Command Pipeline\nservice/command_pipeline.py"]

    PIPE --> AGENT["Agent Planner\nai/agent.py"]
    PIPE -. fallback .-> LEGACY["Legacy NLP Parser\nai/nlp.py::parse_user_command"]
    AGENT --> TOOLS["Tooling\nai/tools.py"]
    AGENT --> CRITIC["Plan Critic\nai/agent.py::run_plan_critic"]
    AGENT --> TRANS["Protocol Translator\nai/protocol_translator.py"]

    TRANS --> SOLVER["Graph Solver\nlogic/graph_solver.py"]
    SOLVER --> IR["IR Normalizer\nlogic/plan_normalizer.py"]
    IR --> TRUST["Plan Trust Gate\nservice/plan_trust_gate.py"]

    TRUST --> COMP["Action Timeline Compiler\nservice/app_service.py::_compile_actions_for_execution"]
    COMP --> EXEC["Action Executor\nservice/action_executor.py"]
    EXEC --> SM["Action State Machine\nservice/action_state_machine.py"]
    SM --> REPO["Repository\nDB (repo/tasks/snapshots)"]

    EXEC --> VERIFY["Post Verify + Repair\napp_service verify/reconcile"]
    VERIFY --> REPO

    SVC --> PENDING["PendingPlan (Preview)"]
    PENDING --> CONFIRM["User Confirm"]
    CONFIRM --> SVC
```

## 3. 核心模块职责

| 层 | 关键文件 | 职责 |
|---|---|---|
| UI | `app.py` | 接收用户输入，展示“处理流程”与“预览变更”，触发确认执行 |
| 编排 | `service/app_service.py` | 总入口，串联解析、编译、执行、回滚、验收 |
| 解析管线 | `service/command_pipeline.py` | `NL -> Agent/Legacy -> Guardrails -> Normalizer` |
| Agent | `ai/agent.py` | ReAct 工具调用、多模型路由、JSON 协议修复、trace 记录 |
| 协议容错 | `ai/protocol_translator.py` | `intent/action` 同义词归一，减少协议噪声 |
| 图到动作 | `logic/graph_solver.py` | `GraphIntent(DAG)` 拓扑求解为线性 actions |
| IR 归一 | `logic/plan_normalizer.py` | 动作别名归一、去重、补 `expected_delta` |
| 信任门禁 | `service/plan_trust_gate.py` | 阻断“格式合法但语义可疑”写入 |
| 执行器 | `service/action_executor.py` + `service/action_state_machine.py` | 单步 `pre-validate -> write -> post-verify -> rollback` |
| 目标态闭环 | `logic/state_diff.py` + `app_service reconcile` | desired_state diff、自动补救、最终验收 |

## 4. 数据契约（可作为论文 Figure 2 的注释）

### 4.1 GraphIntent（Agent 输出）

- 定义：`ai/graph_models.py`
- 根字段：`intent`、`nodes[]`、`reasoning`、`reply_text`、`need_clarification`
- 节点字段：`id`、`action(insert/update/delete/complete)`、`title`、`target_id`、`depends_on`、`time_constraint`、`estimated_minutes` 等

### 4.2 CommandIntent（系统执行 IR 外壳）

- 定义：`ai/models.py`
- 关键字段：`intent`、`actions[]`、`desired_state[]`、`need_clarification`、`parse_source`
- 说明：`GraphIntent` 会被 `graph_solver` 线性化为 `actions[]`。

### 4.3 PendingPlan（预览工件）

- 定义：`service/app_service.py` 中 `PendingPlan`
- 关键字段：`updates`、`actions`、`desired_state`、`state_version`
- 作用：预览与确认执行使用同一工件，避免“预览正确、执行漂移”。

### 4.4 单步执行结果

- 定义：`service/action_state_machine.py` 中 `ActionStepResult`
- 字段：`ok`、`message`、`before_tasks`、`after_tasks`、`rolled_back_count`

## 5. 主流程时序（可作为论文 Figure 3）

### 5.1 用户输入到预览/执行

```mermaid
sequenceDiagram
    participant U as User
    participant UI as app.py
    participant S as app_service.handle_user_command
    participant P as command_pipeline
    participant A as ai.agent
    participant T as ai.tools
    participant G as graph_solver
    participant N as plan_normalizer
    participant TG as plan_trust_gate
    participant C as action compiler
    participant E as action executor
    participant DB as repo/db

    U->>UI: 自然语言请求
    UI->>S: handle_user_command(text)
    S->>P: run_command_pipeline
    P->>A: run_agent (agent-first)
    A->>T: 工具调用(查库/查冲突/解析时间)
    T-->>A: JSON 事实
    A-->>P: GraphIntent
    P->>G: resolve_graph_intent
    G->>N: normalize_command_intent
    N-->>S: CommandIntent(actions)
    S->>TG: evaluate_plan_trust
    TG-->>S: allow/block
    S->>C: _compile_actions_for_execution
    alt intent=plan/replan_all
        S-->>UI: PendingPlan(预览)
        UI->>U: 展示预览并等待确认
    else direct write
        S->>E: execute(action-by-action)
        E->>DB: write
        E->>S: verify/repair result
        S-->>UI: 执行结果
    end
```

### 5.2 预览确认执行（两阶段）

```mermaid
sequenceDiagram
    participant U as User
    participant UI as app.py
    participant S as app_service.apply_pending_plan
    participant DB as repo/db
    participant E as ActionExecutor

    U->>UI: 点击“确认执行”
    UI->>S: apply_pending_plan(plan)
    S->>S: state_version 并发检查
    S->>DB: 保存作用域快照 snapshot
    loop 每个 action
        S->>E: pre-validate
        E->>DB: write
        E->>S: post-verify (可触发 repair)
    end
    S->>S: desired_state reconcile(可选)
    alt 任一步失败
        S->>DB: snapshot 回滚
        S-->>UI: 失败+回滚数量
    else 全部通过
        S-->>UI: 成功
    end
```

## 6. Agent 内部轮次机制（可作为论文 Figure 4）

### 6.1 Provider 路由与 Round 含义

- 路由顺序：先 Gemini（支持 OpenAI-compatible endpoint），失败后 Azure OpenAI。
- “Round n” 表示同一 provider 内的一次 ReAct 迭代：
  - 若模型请求工具：执行工具并把结果回填上下文，进入下一轮。
  - 若模型给出最终答案：尝试解析为 `GraphIntent`。
- 若最终答案不可解析 JSON：
  - 先触发 compiler（`_run_openai_graph_compiler`）做协议修复。
  - 修复失败则提示模型“仅输出合法 JSON”再次 finalize。

### 6.2 防打转与低信号保护

- Stagnation guard：检测重复工具调用批次，超过阈值后强制停止工具并要求直接输出 JSON。
- Invalid-final low-signal 标记：当返回空串/代码块碎片等低信号内容，写入 agent meta。
- `agent_meta` 对下游可见：`protocol_failed`、`compiler_repaired`、`tool_facts` 等。

## 7. 关键鲁棒性闭环

### 7.1 写前门禁

- `AGENT_ONLY_WRITE_MODE`：agent 失败时禁止 legacy 路径直接写库。
- legacy 分支仍保留于代码中（`ai/nlp.py`），主要用于受控兜底与 query 场景。
- `plan_trust_gate` 阻断三类高风险计划：
  - 低信号 compiler 修复结果
  - 唯一已存在任务却无锚点重复 insert
  - `node_x` 依赖未解析就下发执行层

### 7.2 执行器事务语义

- 每步都走统一状态机，不允许分支各写各的。
- 任一步后验失败，优先修复；仍失败则按 snapshot 回滚作用域任务。

### 7.3 目标态验收

- 若有 `desired_state`，执行后做 diff 验收。
- 可选自动补救（配置开关控制），仍不满足则整体失败并回滚。

## 8. 日志与可观测性（论文图注建议）

- 关键日志 marker：`◆AGENT◆`、`◆TOOL◆`、`◆ACTION◆`、`◆VERIFY◆`、`◆ROLLBACK◆`
- Agent 轨迹：`log/agent_activity.jsonl`（含 rounds/tool_calls/final_answer）
- 执行日志：`log/terminal_log`（完整链路）
- 作用：支持“失败定位图”“路径覆盖图”“异常分类统计图”。

## 9. 论文插图建议（直接可画）

1. 图 A（静态架构图）：按第 2 节分层框图，突出 `Agent -> GraphSolver -> ActionExecutor` 主链。
2. 图 B（主时序图）：按第 5.1 节，展示“解析、门禁、编译、执行”。
3. 图 C（两阶段提交图）：按第 5.2 节，突出 `PendingPlan + state_version + snapshot rollback`。
4. 图 D（Agent 内循环图）：按第 6 节，展示 `tool loop -> finalize -> compiler repair -> fallback`。
5. 图 E（状态机图）：`pre-validate -> write -> post-verify -> repair? -> rollback? -> commit`。

## 10. 代码锚点（便于审稿时对照）

- 入口编排：`service/app_service.py::handle_user_command`
- 预览确认执行：`service/app_service.py::apply_pending_plan`
- 统一解析管线：`service/command_pipeline.py::run_command_pipeline`
- Agent 主入口：`ai/agent.py::run_agent`
- Agent JSON 修复：`ai/agent.py::_run_openai_graph_compiler`
- 图求解：`logic/graph_solver.py::resolve_graph_intent`
- IR 归一：`logic/plan_normalizer.py::normalize_command_intent`
- 信任门禁：`service/plan_trust_gate.py::evaluate_plan_trust`
- 单步状态机：`service/action_state_machine.py::run_action_step`
- 目标态差分：`logic/state_diff.py::compute_state_diff`

## 11. 宏观系统架构概念（可作为论文总图）

从研究抽象层面，本系统可以定义为一个“**约束驱动的 Agentic 编译执行闭环**”（Constraint-Driven Agentic Compile-Execute Loop），由五个宏观子系统组成：

1. **意图感知层（Intent Perception）**：把自然语言目标转为结构化任务图（GraphIntent）。
2. **计划编译层（Plan Compilation）**：把图结构约束编译成可执行动作序列（CommandIntent/actions）。
3. **可信执行层（Trusted Execution）**：在门禁与状态机约束下执行动作，失败可修复或回滚。
4. **状态验收层（State Acceptance）**：用目标态差分验证“结果是否真的满足用户目标”。
5. **观测治理层（Observability & Governance）**：通过 trace、标记日志、幂等与快照保证可解释与可恢复。

其核心思想不是“让 LLM 直接写库”，而是“让 LLM 负责提出候选计划，系统负责把候选计划变成可验证、可回滚、可收敛的状态变更”。

```mermaid
flowchart LR
    U["User Goal (NL)"] --> P1["Intent Perception\n(Agent + Tools)"]
    P1 --> P2["Plan Compilation\n(Graph -> Action IR)"]
    P2 --> P3["Trusted Execution\n(Trust Gate + State Machine)"]
    P3 --> P4["State Acceptance\n(Desired-State Verify/Reconcile)"]
    P4 --> R["System State (DB)"]
    R --> O["Observability & Governance\n(Logs/Trace/Idempotency/Snapshot)"]
    O --> P1
```

可在论文中将上述过程概括为：

- **前半环（认知环）**：`Natural Language -> Structured Intent -> Action IR`
- **后半环（控制环）**：`Action IR -> Verified State Transition -> Goal Satisfaction`

这使系统具备三个研究价值特征：

1. **可解释性（Interpretability）**：每次决策都有中间工件（GraphIntent/Action IR/验收结果）。
2. **可控性（Controllability）**：执行前后均有确定性检查点，避免黑箱式落库。
3. **可恢复性（Recoverability）**：失败可局部修复或事务回滚，不破坏全局状态一致性。
