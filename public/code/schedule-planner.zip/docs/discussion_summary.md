# 讨论要点总结

本文档整理日程助手项目相关讨论中的**重要结论与约定**，便于后续开发与科研写作时查阅。详细问题分析见 `llm_problems_in_schedule_demo.md`，科研问题与优先级见 `research_questions_from_demo.md`，多智能体与工具方案见 `multi_agent_and_tools_plan.md`。

---

## 一、已完成的修复（与代码对应）

| 问题 | 原因简述 | 修复位置 |
|------|----------|----------|
| 任务状态回滚（已完成变回待办） | `progress < 100` 且 `done` 时被强制改回 `pending`，UI rerun 时 slider 初始值触发 | `app_service.py`：移除该回滚逻辑，仅 `progress >= 100` 时标记 `done` |
| UI 自动刷屏 | `st.slider` 的 key 未随任务状态变化，与 100% 冲突导致 rerun 循环 | `app.py`：slider key 增加 `t.status`；`app_service.py`：进度未变时提前返回 |
| 自动重规划产生重复任务 | `action='plan'` 时未检查当日同标题待办 | `app_service.py`：同标题且 pending 则更新该任务，不插入新任务 |
| 逾期任务只处理「昨天」 | 仅检查昨天的未完成 | `db/repo.py` 新增 `tasks_overdue_pending(before_date)`；service 将所有逾期延期到今日 |
| 进度条未计时也动态更新 | 按日历时间算进度 | `app.py`：仅「正在计时」时动态更新，否则用 memo 中进度或 0；统一 UTC/本地比较 |
| 相对日期解析错误（如「下周三」） | 相对日期表与用户预期不一致 | `ai/nlp.py`：相对日期参考表与系统提示增加星期标注 |
| 反馈文案无日期 | 重排/新增/完成等反馈未带 YYYY-MM-DD | `app_service.py`：所有反馈行在时间前加日期 |
| 缺少日历视图 | 仅列表无周/月视图 | `app.py`：新增「未来日程」周视图与月视图及样式 |
| 以当前时间规划的任务时间显示错位 | 存库为 UTC，UI 按 UTC 画轴 | `app.py`：新增 `_utc_iso_to_local_hour_minute`，时间轴与列表均用本地时间显示 |

---

## 二、核心科研定位：非传统 NL2SQL

**约定**：不主打传统 NL2SQL（自然语言 → SELECT），而是做**写操作与状态一致性、实体落地、行为序列/个性化、视图维护、工具链幻觉归因**等高价值新问题。

- 与 NL2SQL 的区分：见 `research_questions_from_demo.md` 开头的「核心定位」与「我们聚焦的高价值新问题」表。
- 子问题与优先级：见同文档 §9「优先建议」中的 P0/P1/P2。

---

## 三、高价值选题（综合结论）

在综合 `research_questions_from_demo.md` 与 `multi_agent_and_tools_plan.md` 后的**优先推荐**：

1. **写操作与状态一致性（NL2Ops）**  
   自然语言 → insert/update/delete/plan，参数必须落地到真实实体（如 task_id），写前校验、事务语义；与 VLDB/SIGMOD 写安全、I-Confluence/BridgeScope 衔接。

2. **数据变更后的影响传播与 Agent 上下文的视图维护**  
   基表（任务、日历）变更 → 哪些派生内容（推荐、Agent 读到的上下文）需增量更新；将「Agent 上下文」视为物化视图做增量维护，与 VLDB/SIGMOD 的 view maintenance 衔接。

3. **多步工具使用中的幻觉归因与恢复**  
   读–写工具链中「哪一步导致错误、如何恢复」；通用 Agent 问题，与 AgentHallu 等衔接。

4. **行为序列 → 未来行为（非传统推荐）**  
   预测下一任务类型/下一合适时间段，时间–任务类型–顺序的序列预测，非物品推荐；适合 RecSys/KDD/WWW。

5. **用户行为驱动的「时间–任务类型」匹配与个性化排程**  
   从历史行为反推哪类任务在哪个时段更高效；与 UbiComp/CHI/RecSys 交叉。

6. **实体落地与防幻觉**  
   target_task_id 等必来自检索/工具返回的候选集；支撑「写操作落地」主线，与 epistemic grounding、AgentHallu 衔接。

投稿组合建议：投 VLDB/SIGMOD 可主打 (1)+(2) 或 (1)+(6)；投 RecSys/KDD 可主打 (4) 或 (5)；投 Agent 综合会议可主打 (3)。

---

## 四、关键概念辨析

**意图–实体联合建模 vs Schema alignment**

- **意图–实体联合建模**：在**同一模型**里联合做意图识别与槽位/实体填充（如 JointBERT），关注「怎么建模、怎么预测」。
- **Schema alignment**：把用户自然语言中的概念**映射到系统/数据库的 schema**（表、列、API 参数），关注「语义到结构的对齐、落地到哪一列/哪个接口」。

二者相关但不等同：任务型对话里常先做意图–实体联合建模（识别要干什么、提到了哪些实体），再做 schema alignment（把这些实体填到哪个表/列/API）。写论文时若提「意图–实体联合建模」，不要与「schema alignment」混为一谈。

---

## 五、多智能体与工具方案（引用）

- 目标：意图更准、实体可落地、操作可校验；手段：统一工具层（get_tasks_for_date、search_tasks、parse_time、get_free_slots、validate_slot、get_task_by_id），再选单 Agent+工具循环 或 管道式多 Agent 或 编排器+专家。
- 实施顺序：先统一工具层 → 优先方案 1（工具增强单 Agent）→ 效果不足再方案 2/3；框架上方案 1 暂不引入，方案 2 优先 LangGraph，方案 3 在 LangGraph 与 CrewAI 间选型。

详见 `multi_agent_and_tools_plan.md`。

---

## 六、从日志暴露的未解决问题（待改进）

**案例**：用户输入「2.2号还看了oscar的论文，写mteb求lid的代码，skyline的实验。」

- **预期**：用户在**记录 2 月 2 日已发生的活动**，应识别为「记录已发生」：对已有任务做 complete（若存在）或 insert 为**已结束**的区间（start_iso/end_iso 为 2.2 的已过时段），且「skyline的实验」应与当日已有的「skyline实验」关联（更新/完成），而不是再插一条新任务。
- **实际**：被识别为 intent=insert，插入了 3 条**新**的 pending 任务，且时间被写成 2026-02-01T16:00:00 到 2026-02-02T15:59:59（UTC），与「2.2 号还看了」的语义不符；另外产生了与当日已有「skyline实验」同义的「skyline的实验」重复任务。

**暴露的问题**：

1. **「记录已发生」vs「新增未来待办」** 的意图区分仍不足：提示词虽有「记录已发生」优先规则，但在「X号还看了/做了 A、B、C」这种多句并列时，仍被整体判成「新增待办」。
2. **跨日 + 多实体** 时，与当日已有任务的**去重与关联**（同标题/同义）未做：应对「skyline的实验」与「skyline实验」做匹配，更新或完成而非再插一条。
3. **过去日期的 insert** 若表示「已做」，应在业务上视为「已结束区间」或直接 complete 已有任务，而不是生成未完成的跨日块。

可作为后续 prompt 优化、意图细分或「记录已发生」专用分支的改进依据，也可纳入「意图–实体联合建模」「实体落地与去重」等科研问题的 Badcase 集。

---

## 七、文档索引

| 文档 | 用途 |
|------|------|
| `docs/discussion_summary.md` | 本文：讨论要点与结论速查 |
| `docs/research_questions_from_demo.md` | 科研问题清单、优先级、与顶会/文献对应 |
| `docs/multi_agent_and_tools_plan.md` | 多智能体与外部工具方案、实施顺序与框架选型 |
| `docs/llm_problems_in_schedule_demo.md` | 用 LLM 做日程助手时的问题详解、研究问题凝练与基准缺口 |

---

*文档随讨论与代码变更可增补修订；若某问题已落地为代码或论文，可在本节或对应文档中标注。*
