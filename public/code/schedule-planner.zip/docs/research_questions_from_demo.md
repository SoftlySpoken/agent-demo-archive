# 从日程助手 Demo 引出的科研问题（可泛化 · 2025–2026 热点衔接）

本文档从本项目的日程助手 demo 出发，提炼**可泛化**的科研问题，并尽量与 **2025–2026 年受关注** 的方向对齐，便于发论文、开题或申请项目。

---

## 核心定位：不做传统 NL2SQL，做高价值新问题

**传统 NL2SQL / Text-to-SQL**（自然语言 → 单条/多条 SELECT）已有大量工作（Spider、Bird、RubikSQL、TailorSQL 等），本方向**刻意不以此为主打**。我们聚焦的是**更新、价值更高、与 NL2SQL 有本质差异**的问题，便于做出区分度强、易发顶会/顶刊的贡献。

### 我们刻意不主打的方向（作为相关 work 即可）

| 方向 | 说明 |
|------|------|
| **NL2SQL / Text-to-SQL** | 自然语言 → SQL 查询的翻译、准确率、benchmark；已有 Spider、Bird、RubikSQL、AskDB 等，不重复造轮子。 |
| **以“查询理解 + 单次查询生成”为核心** | 把问题收缩成“用户问一句 → 生成一条 SELECT”，不涉及写操作、状态一致性、行为序列、视图维护等。 |

### 我们聚焦的高价值新问题（非 NL2SQL，易发文章）

| 方向 | 核心差异与价值 | 对应章节 |
|------|----------------|----------|
| **写操作与状态一致性（NL2Ops / 操作落地）** | 自然语言 → **insert/update/delete/plan**，且操作参数必须**落地到真实实体**（如 task_id），写前校验、事务语义、回滚；与“只读查询”本质不同，数据库社区对**写安全、ACID、审计**的需求强，且现有 NL2SQL 工作较少系统做写链。 | §1、§7、§8.1 |
| **行为序列 → 未来行为（非传统推荐）** | 用**行为序列**预测“下一任务/下一时间段”，是**时间–任务类型–顺序**的预测与推荐，**不是**物品推荐、也不是“查库答问”；问题形式化、评估与 RecSys 传统任务不同，创新性高。 | §8.3、§8.4 |
| **Agent 上下文的视图维护与影响传播** | 当基表（任务、日历）变更时，**哪些派生内容**（推荐、摘要、Agent 读到的上下文）**需增量更新**；这是 **view maintenance / incremental computation** 在“Agent 所依赖的上下文”上的应用，与 VLDB/SIGMOD 经典方向直接衔接，且目前少有人把“Agent 上下文”当作一类需维护的视图。 | §8.6 |
| **用户行为驱动的“时间–任务类型”匹配与反思** | 从**历史行为**反思“哪类任务在哪个时间段更高效”，数据驱动的个性化排程，**不是**静态规则也不是“查库答问”；与 UbiComp/CHI/RecSys 的个性化、行为建模交叉，价值高。 | §8.3 |
| **约束形式化与可验证排程** | 用户与日历**约束**的形式化（CSP/SMT）、排程结果的**可验证性**、与 LLM 生成的混合架构；**不是**“生成 SQL”，而是“生成满足约束且可验证的计划”，与形式化方法、数据库约束与验证结合。 | §8.7 |
| **长期模糊任务规划** | **模糊、长期**目标（如“把论文写完”）的分解、细化与排程；**不是**单轮问答或单条 SQL，而是规划+调度+与 LLM 的协作，与 ICAPS/AAAI 规划社区衔接。 | §8.5 |
| **安全与审计、MCP 标准化** | Agent **写**库的安全策略、审计溯源、以及 MCP 等协议对“Agent–DB 上下文”的标准化；系统/协议向，与 NL2SQL 的“翻译准确率”不同。 | §8.2、§6 |
| **多步工具使用中的幻觉归因与恢复** | 工具链中**哪一步**导致错误、如何**恢复**；适用于“读–写工具链”等任意 Agent+工具场景，不限于 SQL。 | §3 |

以上方向均可泛化到**日程之外**（工单、库存、配置管理等“操作+状态+行为”场景），且与 NL2SQL 形成清晰区分，便于在摘要与引言中**一句话点明“我们不做 NL2SQL，我们做……”**。

---

## 一、意图理解与实体落地（NLU / 任务型对话）

### 1.1 从 Demo 直接引出的问题

- **意图歧义**：insert vs update、plan vs query、「记录已发生」vs「安排未来」等易混意图的细粒度分类与数据设计。
- **指代与实体落地**：「那个会」「下周三的会」如何稳定对应到真实 `task_id`，避免模型编造不存在的 id。
- **跨轮指代**：用户先说「加一个会」再说「改到下午」时的指代解析与对话状态追踪。

### 1.2 可泛化科研问题（2025–2026 关注）

| 问题 | 泛化表述 | 相关热点 / 工作 |
|------|----------|----------------|
| **任务型对话中的意图–实体联合建模** | 在有限动作空间（insert/update/delete/query 等）下，如何联合建模意图与实体链接，并保证实体必来自检索/工具返回的候选集？ | 任务型对话基准、Tool-Augmented LLMs、grounding 到知识库/API |
| **Hallucination 与 grounding 的边界** | 何时应禁止模型“发明”实体 id/键值，如何用形式化约束或工具强制 grounding？ | AgentHallu（工具使用幻觉归因）、FACTS Grounding、epistemic competence |
| **低资源意图与槽位持续学习** | 如何用少量用户修正（如「不对，是改不是加」）做意图/槽位的持续学习而不灾难性遗忘？ | RLUF、Pref-GUIDE、WildFeedback、continual preference learning |

---

## 二、时间与排程推理（Temporal Reasoning）

### 2.1 从 Demo 直接引出的问题

- **相对时间解析**：「下周三」「明天下午」等在多用户、多时区、多日历习惯下的鲁棒与一致解析。
- **约束排程与重规划**：在「当前时间 + 已有任务 + 时长/优先级」约束下的“合理”排程形式化与用户偏好（早排/晚排、冲突提示）。
- **时间不确定性**：「大概两小时」「可能下午」的表示与系统接口衔接。

### 2.2 可泛化科研问题（2025–2026 关注）

| 问题 | 泛化表述 | 相关热点 / 工作 |
|------|----------|----------------|
| **自然语言时间表达式 → 规范时间** | 如何建立可复现的、带时区与日历约定的时间解析基准，并评估 LLM 与专用模型的差距？ | TIME benchmark、Test of Time、TIMEBENCH；LLM 时间推理与人类差距 |
| **时序约束下的决策与解释** | 在带时序约束的决策任务（排程、行程、资源分配）中，如何生成既满足约束又可解释的决策，并评估“合理性”？ | 可解释规划、preference-based scheduling、human-AI alignment in sequential decision |
| **时间不确定性在对话系统中的表示与利用** | 用户表达的时间模糊性（区间、概率、偏好）如何在对话状态与 API 调用中表示，并驱动澄清或多方案展示？ | 不确定性对话状态、clarification strategies |

---

## 三、工具使用与智能体（Agent / Tool Use）

### 3.1 从 Demo 直接引出的问题

- **何时调用何工具**：在延迟与成本约束下，如何决定「先查任务再解析」还是「直接解析」。
- **工具结果压缩与注入**：工具返回多条任务或大段日历时，如何压缩后注入上下文且不丢关键信息。
- **工具链组合与执行前校验**：get_tasks → search_tasks → validate_slot 等组合的发现与形式化校验（如“更新前必须存在 task_id”）。

### 3.2 可泛化科研问题（2025–2026 关注）

| 问题 | 泛化表述 | 相关热点 / 工作 |
|------|----------|----------------|
| **Agent 的“认知能力”评估：grounding / recovery / calibration** | 智能体是否知道何时需查证（grounding）、查证失败时如何恢复（recovery）、何时证据充足可作答（calibration）？ | SeekBench、epistemic competence in information-seeking agents |
| **多步工具使用中的幻觉归因** | 在多步工具调用链中，如何自动定位“哪一步”导致最终错误或幻觉？ | AgentHallu（Planning / Retrieval / Reasoning / Human-Interaction / Tool-Use 五类幻觉；tool-use 最难，约 11.6% 步骤定位准确率） |
| **工具调用与推理的交替优化** | 多轮「推理 → 工具调用 → 再推理」中，如何优化调用顺序与轮次，在延迟/成本与准确率间取得平衡？ | Multi-hop interleaved RAG（MIRAGE）、dynamic RAG agents vs single-turn RAG |
| **Agent 评估的维度与基准** | 除“答案对错”外，如何系统评估行为、能力、可靠性、安全性、成本效率与鲁棒性？ | Evaluation and Benchmarking of LLM Agents (survey)；realistic, long-horizon, enterprise 场景 |

---

## 四、用户反馈与个性化（HCI / 人机协作）

### 4.1 从 Demo 直接引出的问题

- **从用户修正中学习**：用户说「不对，是下周二」「是改时间不是删除」时，如何转为结构化反馈并用于改进。
- **何时澄清 vs 何时猜测**：置信度不足时，主动澄清与“最佳猜测 + 可撤销”的权衡。
- **规划可解释性与信任**：planning_reason 如何既简洁又切中用户关心的点，与采纳率的关系。

### 4.2 可泛化科研问题（2025–2026 关注）

| 问题 | 泛化表述 | 相关热点 / 工作 |
|------|----------|----------------|
| **从真实用户反馈做策略优化（无显式奖励）** | 如何利用生产环境中的隐式反馈（点击、修正、撤销、重复请求）做策略优化，应对二值、稀疏与偶发对抗反馈？ | RLUF (Reinforcement Learning from User Feedback)、WildFeedback、Pref-GUIDE |
| **测试时偏好优化（无参数更新）** | 能否在推理阶段通过“文本式批评”迭代优化回复，使未对齐模型在数步内逼近或超过已对齐模型？ | Test-Time Preference Optimization (TPO) |
| **可解释性与信任的实证关系** | 在任务型/决策型系统中，不同形式的解释（理由、替代方案、不确定性）如何影响用户信任与采纳？ | Explainable AI in human-AI collaboration、trust calibration |

---

## 五、评估与基准（Evaluation / Benchmark）

### 5.1 从 Demo 直接引出的问题

- **意图与操作级评估**：如何构建「用户话术 → 期望 intent + actions + 可选 task_id」的标注集与指标。
- **自动指标与用户满意度的一致性**：意图准确率、实体正确率等与用户满意度、任务完成度的关系。
- **回归与鲁棒性**：历史 Badcase 与边界表达的回归测试集与通过准则。

### 5.2 可泛化科研问题（2025–2026 关注）

| 问题 | 泛化表述 | 相关热点 / 工作 |
|------|----------|----------------|
| **任务型对话 + 实体链接 + 工具调用的端到端基准** | 是否存在或应构建涵盖多轮、多意图、实体链接与工具调用的统一基准，便于比较不同架构与训练方式？ | Agent 评估综述中的 benchmark 缺口、domain-specific (e.g. calendar/scheduling) 基准 |
| **幻觉的细粒度分类与可归因评估** | 幻觉是否应对“任务指令、执行历史、环境观察”等维度做细粒度分类，并支持步骤级归因？ | MIRAGE-Bench、AgentHallu、HalluLens |
| **长程交互与成本效率的联合评估** | 如何在同一框架下评估长程多轮交互的完成率、安全性与 token/调用成本？ | Agent evaluation taxonomy、cost-efficiency in agent systems |

---

## 六、系统与安全（Systems / 安全与部署）

### 6.1 从 Demo 直接引出的问题

- **多 Agent vs 单模型**：在固定延迟/成本下，不同架构的准确率–延迟–成本曲线。
- **失败降级与安全护栏**：工具超时、非法输出、校验不通过时的分级降级与“不误执行写操作”的保证。
- **多用户/多日历与隐私**：多日历源、权限与最小暴露的上下文裁剪。

### 6.2 可泛化科研问题（2025–2026 关注）

| 问题 | 泛化表述 | 相关热点 / 工作 |
|------|----------|----------------|
| **Agent 的可靠性与安全评估** | 如何系统评估 Agent 在对抗输入、工具故障、超时下的鲁棒性，以及写操作前的安全护栏？ | Agent evaluation (reliability, safety)、guardrails、refusal and fallback |
| **角色与数据边界下的 Agent 行为** | 在企业/多租户场景下，如何评估与保证 Agent 在“角色 + 数据访问边界”约束下的正确行为？ | Enterprise agents、role-based data access、compliance |

---

## 七、Agent + Database 专题

本小节集中提炼 **Agent 与数据库** 交叉方向的科研问题：既来自 demo 中「自然语言 → 查库/写库」的闭环，也可泛化到 Text-to-SQL、CRUD Agent、数据驱动的对话系统等。

### 7.1 从 Demo 直接引出的问题

- **实体与主键落地**：「那个会」必须对应真实 `task_id`，不能由模型编造 id；更新/删除前需校验记录存在。
- **读–写工具链**：get_tasks_for_date / search_tasks（读）→ 解析意图与实体 → insert_task / update_task（写）；读的结果如何约束写的参数（如 target_task_id 必在候选集中）。
- **写前校验与一致性**：插入前检查时间段冲突、更新前检查外键/存在性；多步写（如重规划更新多条）的原子性与回滚。
- **上下文与 token**：日历/任务列表可能很长，如何压缩后注入 prompt 且不丢关键信息。

### 7.2 可泛化科研问题（Agent + Database）

| 问题 | 泛化表述 | 相关热点 / 工作 |
|------|----------|----------------|
| **自然语言到数据库操作的 grounding** | Agent 生成的「操作参数」（主键、外键、时间范围等）必须来自数据库查询结果或约束，如何从模型层面或系统层面强制「无幻觉 id」？ | Text-to-SQL grounding、Bird/Spider 2.0、AgentHallu (tool-use)、epistemic competence |
| **Agentic Text-to-SQL：多轮、工具、写操作** | 不仅 NL → 单条 SELECT，而是多轮对话、多步工具调用（查表/查约束）、以及 INSERT/UPDATE/DELETE；如何评估与优化？ | Spider 2.0 (ICLR 2025)、Bird-Interact (cc-Interact / aa-Interact)、CRUD 全谱评估 |
| **数据库写操作的事务语义与错误处理** | Agent 提议的多条写操作如何满足原子性、一致性；若部分失败如何回滚或补偿；如何检测「语义错误」（如违反业务约束）并交由人工或自动修复？ | I-Confluence (invariant satisfaction)、semantic errors in LLM-generated transactions、BridgeScope (ACID, 工具化 CRUD) |
| **Schema 感知与演化** | Agent 如何理解表结构、主外键、约束，并在 schema 变更（增列、改类型）时仍生成合法操作？如何用 schema 信息压缩上下文、减少幻觉？ | Schema-guided generation、Text-to-SQL schema encoding、BridgeScope (security-aware, token 压缩) |
| **读–写分离与最小权限** | 在「先读后写」的流程中，如何按角色/权限只暴露可读可写的表与列，使 Agent 的上下文与操作范围受控？ | Role-based data access、enterprise agent evaluation、BridgeScope (privilege management) |
| **长表/大结果集的表示与注入** | 查询返回大量行或宽表时，如何摘要、采样或检索后再注入 Agent 上下文，在控制 token 的前提下保留对当前意图关键的信息？ | Long-context + tool result summarization、RAG over DB results、MIRAGE (multi-hop retrieval) |
| **Agent + Database 的端到端评估** | 除「SQL 执行正确」外，如何评估「意图–实体–操作」链的正确性、写操作后的状态一致性、以及多轮对话下的任务完成度？ | Spider 2.0 agent-based evaluation、Bird-Interact (multi-turn, CRUD)、task-oriented dialogue + DB benchmark |
| **时序/快照与并发** | 多用户或多次请求下，Agent 读到的状态与随后写时的状态可能已变；如何定义「基于某快照的读写」、冲突检测与乐观锁/重试？ | Temporal DB、snapshot isolation、concurrent agent writes |

### 7.3 与现有章节的对应

- **实体落地**（§1）→ 本专题的「自然语言到数据库操作的 grounding」「无幻觉 id」。
- **工具使用**（§3）→ 本专题的「读–写工具链」「Schema 感知」「长结果注入」。
- **评估**（§5）→ 本专题的「Agent + Database 端到端评估」「事务/一致性评估」。
- **系统与安全**（§6）→ 本专题的「读–写分离与最小权限」「事务语义与错误处理」。

### 7.4 VLDB / ICDE / SIGMOD 2025–2026 与数据库社区关注点

本小节将 §7.2 中的科研问题与 **VLDB、ICDE、SIGMOD** 及 **数据库领域大佬（如 Michael Stonebraker、Andy Pavlo）** 在 2025–2026 年的文章、博客、研讨会观点对齐，便于投数据库顶会或与 DB 社区对话。

#### 7.4.1 主要会议/研讨会与代表性工作

| 会议/研讨会 | 时间 | 与 Agent+DB 相关的代表性工作 |
|-------------|------|------------------------------|
| **VLDB 2025** | 2025 | **AIDB** (Applied AI for Database Systems)：RDBMS 中 LLM 查询的**结构化输出、资源利用、查询规划**挑战；**TailorSQL**（利用历史 workload 提升 NL2SQL 准确率与延迟，约 2×）；**MageSQL**（图式 demo 选择与纠错）；**Grounding LLMs for Database Exploration**（用户意图限定与复述，多数据集鲁棒性）。**GuideAI**：DBMS–LLM 集成的**五类架构模式**（DATA+AI 范式）。 |
| **VLDB 2026** | 2026 | **RubikSQL**（投稿）：将 NL2SQL 视为**终身学习**任务，知识库维护 + 多 Agent 工作流；应对隐式意图、领域术语、宽表、上下文敏感；**RubikBench** 基准。 |
| **SIGMOD 2025–2026** | 2025–2026 | **λ-Tune**：LLM 生成整份配置脚本、成本导向减少调用；**LLM4Hint**：离线查询优化的 hint 推荐；**SEFRQO** (SIGMOD 2026)：基于 RAG 的自进化查询优化器，执行反馈持续学习；**GPTuner**：LLM 驱动的数据库调优；**QUITE**：用 LLM Agent 做**查询重写**（超越规则），多 Agent + 实时 DB 反馈，执行时间可降约 35.8%。 |
| **ICDE / CIDR** | 2025 | **SWAN**：需**库内 + 库外知识**的“超越数据库”问答基准；**TKDE 2025**：下一代数据库接口综述（含 NL2SQL）。 |
| **其他** | 2025 | **AskDB**：统一 Agent 支持**数据分析 + 库管理**（自然语言），schema 感知与任务分解；**MAC-SQL**：多 Agent 协作 Text-to-SQL；**DB-Explore**：自动库探索与指令合成；**Spider 2.0** (ICLR 2025)、**Bird-Interact**：多轮/Agentic Text-to-SQL 与 CRUD 评估。 |

#### 7.4.2 数据库领域大佬的观点与方向（2025–2026）

| 人物/项目 | 与 Agent+DB 相关的观点或方向 |
|-----------|-----------------------------|
| **Michael Stonebraker**（图灵奖，Postgres/Vertica/DBOS 等） | 与 Andy Pavlo 在 **Data 2025: Year in Review** 等对谈中强调：**Agentic AI 需要 PostgreSQL 级可靠性与事务语义**；讨论「AI Agent 是否会取代 DBA」、AI 与数据库的相互影响；DBOS 将 OS 构建于分布式数据库之上，满足持久化队列等需求，与 Agent 工作流中的可靠状态存储相呼应。 |
| **Andy Pavlo**（CMU，SIGMOD Jim Gray 博士论文奖） | 同上对谈；关注**自治数据库系统**、查询优化与 AI 结合；sydht.ai 等方向与「数据库 + AI」交叉。 |
| **Agentic Postgres**（Timescale/TigerData 等） | **“为 AI Agent 设计的数据库”**：集成 MCP、向量、混合检索、可观测性；支持自然语言到复杂查询与写操作；反映工业界对「Agent 需要与 DB 深度集成」的共识。 |
| **工业界**（Amazon, Databricks, Google, Snowflake） | 在 SQL 内直接调用 LLM 的实践；挑战集中在**结构化输出、资源优化、查询规划**及**隐私与本地部署**需求（VLDB 2025 AIDB 综述）。 |

#### 7.4.3 科研问题与 VLDB/ICDE/SIGMOD 及大佬观点的对应

| §7.2 中的科研问题 | 对应的会议/工作/大佬观点 |
|-------------------|--------------------------|
| **自然语言到数据库操作的 grounding** | VLDB AIDB「Grounding LLMs for DB Exploration」；Spider 2.0 / Bird-Interact 的 agent-based 评估；Stonebraker/Pavlo 强调的「Agent 需要可靠、可验证的 DB 状态」。 |
| **Agentic Text-to-SQL：多轮、工具、写操作** | VLDB RubikSQL（终身学习 + 多 Agent）；AskDB（分析 + 管理）；Bird-Interact (cc/aa-Interact)；SIGMOD QUITE（查询重写 Agent）。 |
| **数据库写操作的事务语义与错误处理** | I-Confluence、BridgeScope；Stonebraker 一脉对 **ACID、持久化、可恢复** 的强调；Agentic Postgres 等产品对「Agent 写操作」的工程化。 |
| **Schema 感知与演化** | TailorSQL、MageSQL、DB-Explore；AskDB 的 schema 感知与任务分解；VLDB AIDB 中的「宽表、多表」挑战。 |
| **读–写分离与最小权限** | BridgeScope 的 privilege 管理；企业场景下的 role-based 访问（SIGMOD/VLDB 企业/安全相关 track）。 |
| **长表/大结果集的表示与注入** | VLDB AIDB「资源利用、长上下文」；TailorSQL 的 workload 与上下文压缩；RubikSQL 的知识库索引与检索。 |
| **Agent + Database 的端到端评估** | Spider 2.0 agent-based evaluation；Bird-Interact；RubikBench；VLDB/SIGMOD 对「执行正确性 + 任务完成度 + 一致性」的评估需求。 |
| **LLM 内嵌于 SQL / 查询优化与调优** | VLDB AIDB「RDBMS for LLM queries」；SIGMOD λ-Tune、LLM4Hint、SEFRQO、GPTuner、QUITE；工业界「SQL 内调用 LLM」的优化与规划。 |
| **终身学习与领域适应** | RubikSQL（NL2SQL as lifelong learning）；TailorSQL（workload 适应）；与 Stonebraker/Pavlo 讨论的「AI 与数据库共同演化」相呼应。 |
| **“超越数据库”的问答（库内+库外知识）** | SWAN 基准；与日程 demo 中「用户意图 + 日历 + 外部常识」的混合推理可类比。 |

#### 7.4.4 可重点跟进的数据库顶会方向（2025–2026）

- **VLDB**：AIDB、GuideAI 研讨会；NL2SQL、DBMS–LLM 集成、grounding、终身学习（RubikSQL 等）；VLDB 2026 投稿可关注 RubikSQL、RubikBench 及类似“企业级 NL2SQL + Agent”工作。
- **SIGMOD**：查询优化与调优中的 LLM（λ-Tune、LLM4Hint、SEFRQO、GPTuner、QUITE）；Agent 驱动的查询重写与计划选择；可靠性与资源利用。
- **ICDE / CIDR**：下一代数据库接口（TKDE 综述）；超越单库的问答与混合知识（SWAN）；与 NL/Agent 的接口标准化。
- **大佬博客/对谈**：Stonebraker、Pavlo 的「Data 2025 Year in Review」及后续；Agentic Postgres、DBOS 等项目的技术博客；各厂商（Snowflake、Databricks 等）在 VLDB/SIGMOD 上的 industry track。

---

## 八、补充科研问题（可发文章级）

以下将「丰富操作–数据库匹配、安全、MCP、用户行为与反思、行为序列→未来行为、实时推荐、长期模糊规划、影响传播与视图维护、约束形式化」等方向，整理为**可泛化、易发文章**的科研问题，并补充进文档。

### 8.1 丰富自然语言操作到数据库操作的匹配

| 问题 | 泛化表述 | 创新点 / 发文章角度 |
|------|----------|---------------------|
| **复杂意图到多步数据库操作的分解与映射** | 用户一句话可能对应多条 CRUD、多表写入、或“先查再改”的复合操作；如何从**丰富操作空间**（自然语言表达的多种动作）稳定映射到**有限的数据库操作**（API/事务），并保证分解后的操作序列可执行、可回滚？ | 操作分解（decomposition）、意图–操作对齐、多步写的事务边界；可与 NL2SQL 的“复杂查询分解”对比，强调 **write/update 的分解与一致性**。 |
| **操作空间与 schema 的联合建模** | 不同应用域（日程、工单、库存）的“操作”与底层表/约束不同；如何形式化**操作空间–schema–约束**的对应关系，使 Agent 在 schema 变更或新域接入时仍能生成合法操作？ | 可迁移的操作–schema 表示、domain adaptation、few-shot 操作映射。 |

### 8.2 安全与 MCP（Model Context Protocol）

| 问题 | 泛化表述 | 创新点 / 发文章角度 |
|------|----------|---------------------|
| **Agent + Database 的安全与审计** | 如何防止 Agent 生成的写操作导致越权、注入或误删；如何对“谁在何时对哪些数据执行了何种操作”做**可审计**的日志与溯源？ | 写前策略检查（policy）、最小权限上下文、审计日志与因果链；可结合 BridgeScope 的 privilege、I-Confluence 的语义错误检测。 |
| **MCP 与数据库上下文的标准化** | Model Context Protocol 等协议如何标准化“Agent 从数据库获取的上下文”（schema 摘要、查询结果、权限范围），使多 Agent、多数据源在**同一套接口**下工作？ | 协议设计、上下文契约、与现有 DB 驱动/ORM 的兼容；工业界 MCP 已用于 Agentic Postgres 等，可做“协议评估与优化”类工作。 |

### 8.3 用户行为、反思与时间–任务类型匹配

| 问题 | 泛化表述 | 创新点 / 发文章角度 |
|------|----------|---------------------|
| **从用户行为反思“高效时间段–任务类型”匹配** | 利用历史行为数据（用户在何时完成了何种类型任务、完成率/中断率如何），**反思总结**出“哪类任务在哪个时间段更高效”，并反哺排程建议（如深度工作放上午、会议放下午）。 | 区别于“静态规则”：数据驱动的**时间–任务类型**匹配；可做可解释性（为何推荐该时段）。 |
| **时间段 + 历史行为数据的个性化调优** | 在给定时间段与任务类型下，用**历史行为**（完成时长、实际开始/结束时间、修改频率）调优排程模型或推荐策略，形成个性化偏好。 | 个性化排程、从行为反推偏好、冷启动与持续学习。 |

### 8.4 行为序列 → 未来行为（非传统推荐）

| 问题 | 泛化表述 | 创新点 / 发文章角度 |
|------|----------|---------------------|
| **行为序列建模预测“下一步任务/时间段”** | 将用户的历史**行为序列**（任务类型、时间段、顺序、间隔）建模，预测“下一时刻用户更可能做什么类型的任务、哪个时间段更合适”，用于**实时建议**或预排程。 | **非传统推荐**：不是“推荐物品”，而是“推荐时间–任务类型–顺序”；序列依赖、时序因果、与 session-based 推荐的差异；创新性在于问题形式化与评估指标。 |
| **高效实时推荐（next task / next slot）** | 在**低延迟、流式更新**下，根据当前上下文与最新行为，推荐“下一个任务”或“下一个可用时间段”；增量更新、缓存与视图维护、与离线推荐系统的协同。 | 实时系统、流式行为、延迟–准确率 trade-off；可发系统+算法结合的文章。 |

### 8.5 长期任务规划与模糊任务

| 问题 | 泛化表述 | 创新点 / 发文章角度 |
|------|----------|---------------------|
| **长期任务规划中的模糊任务分解与细化** | 用户给出**模糊、长期**的目标（如“把论文写完”“准备答辩”），如何自动分解为可执行、可排程的子任务，并在执行过程中根据进度与反馈**动态细化/调整**？ | 模糊任务表示、层次化规划、与 LLM 的协作（生成子任务 + 排程）；与经典 HTN、MDP 的对比与结合。 |
| **模糊约束与偏好学习** | 用户表达“尽量上午”“不要太晚”等**模糊约束**；如何形式化并学习这些偏好，在排程与重规划中满足软约束？ | 模糊约束满足、偏好学习、与硬约束（截止时间、不可用时段）的联合处理。 |

### 8.6 自动监测、影响传播与视图维护

| 问题 | 泛化表述 | 创新点 / 发文章角度 |
|------|----------|---------------------|
| **数据变更后的影响分析与“需更新内容”的识别** | 当底层数据（任务、日历、依赖）发生变更时，**自动监测并分析**哪些**派生内容**（已生成的计划、推荐、缓存、视图）**受影响、需要更新**；形式化为依赖图与传播规则。 | 影响传播（impact propagation）、增量一致性、与 view maintenance 的结合；可泛化到任意“基表 → 派生视图/推荐”的 pipeline。 |
| **Agent 上下文的视图维护** | Agent 依赖的“当前任务列表”“空闲时段”“用户偏好摘要”等可视为**物化视图或缓存**；基表（tasks、events）更新后，如何**增量维护**这些视图，使 Agent 始终读到一致且不过时的上下文？ | Incremental view maintenance、materialized views for LLM context、与 DB 社区 view maintenance 文献的衔接（VLDB/SIGMOD）。 |

### 8.7 约束形式化与可验证排程

| 问题 | 泛化表述 | 创新点 / 发文章角度 |
|------|----------|---------------------|
| **用户与日历约束的形式化与可验证性** | 将用户表达的约束（时间、优先级、依赖、不可用、偏好）形式化为**约束满足问题（CSP）或 SMT**，使排程结果可**验证**（满足所有硬约束）、可**解释**（指出冲突或松弛了哪些软约束）。 | 形式化方法、可验证 AI、与 LLM 生成 + 约束求解器的混合架构；适合偏形式化/偏数据库的会议。 |
| **约束与自然语言的双向映射** | 从自然语言**抽取**约束，或从约束**生成**自然语言解释；便于用户理解“为什么这样排”或“哪些约束无法同时满足”。 | NL–constraint 对齐、可解释排程、人机协同。 |

### 8.8 与现有章节及会议方向的对应

| §8 中的方向 | 对应前文 | 适合投稿/交叉 |
|-------------|----------|----------------|
| 丰富操作–DB 匹配（§8.1） | §7 Agent+DB、§1 意图–实体 | VLDB/SIGMOD（操作分解、CRUD 全谱）；NLP（意图分解）。 |
| 安全与 MCP（§8.2） | §6 系统与安全、§7 读–写分离 | VLDB/SIGMOD（安全、审计）；系统/协议（MCP 评估）。 |
| 用户行为与时间–任务匹配（§8.3） | §4 用户反馈与个性化 | RecSys、UbiComp、CHI（行为+个性化）；与“传统推荐”的差异可强调。 |
| 行为序列→未来行为、实时推荐（§8.4） | §2 时间推理、§4 个性化 | RecSys、KDD、WWW（序列预测、实时推荐）；创新点：**时间–任务–顺序**而非物品推荐。 |
| 长期模糊规划（§8.5） | §2 排程推理 | ICAPS、AAAI（规划）；NLP（模糊任务理解）。 |
| 影响传播与视图维护（§8.6） | §7 Agent+DB | **VLDB/SIGMOD**（view maintenance、incremental computation）；与 DB 社区直接对话。 |
| 约束形式化（§8.7） | §2 约束排程 | VLDB/ICDE（约束、验证）；形式化方法会议。 |

---

## 九、优先建议（高价值 + 可泛化 + 与热点衔接）

**说明**：下表**优先列出非 NL2SQL、价值极高、易发文章**的方向；NL2SQL 相关项仅作“相关 work 对比”用，不主打。

### 9.1 核心方向（非 NL2SQL，高价值，建议主打）

| 优先级 | 科研问题 | 理由 |
|--------|----------|------|
| **P0** | **写操作与状态一致性（NL2Ops / 操作落地）** | **非 NL2SQL**：自然语言 → insert/update/delete/plan，且参数**落地到真实实体**（task_id）、写前校验、事务语义；与“只读查询”本质不同，数据库社区对写安全、ACID、审计需求强；可与 I-Confluence、BridgeScope 等衔接，易发 VLDB/SIGMOD。 |
| **P0** | **行为序列 → 未来行为（非传统推荐）** | **非 NL2SQL、非传统推荐**：时间–任务类型–顺序的预测与推荐，不是物品推荐、也不是“查库答问”；问题形式化与评估有创新性，适合 RecSys/KDD/WWW。 |
| **P0** | **数据变更后的影响传播与 Agent 上下文的视图维护** | **非 NL2SQL**：基表变更 → 哪些派生内容（推荐、Agent 上下文）需增量更新；与 VLDB/SIGMOD 的 **view maintenance、incremental computation** 直接衔接，少有人把“Agent 上下文”当视图维护对象，价值高。 |
| **P0** | **多步工具使用中的幻觉归因与恢复** | 工具链中“哪一步错、如何恢复”；适用于读–写工具链等任意 Agent+工具场景，不限于 SQL；与 AgentHallu 等热点衔接。 |
| **P1** | **用户行为驱动的“时间–任务类型”匹配与个性化排程** | **非 NL2SQL**：从历史行为反思“哪类任务在哪个时间段更高效”，数据驱动的个性化排程；与 UbiComp/CHI/RecSys 交叉，价值高。 |
| **P1** | **实体落地与防幻觉（工具/检索结果约束下的实体链接）** | 写操作前**必须**用检索/工具结果约束实体 id，避免编造；与 AgentHallu、epistemic grounding 衔接，支撑“写操作落地”这一核心。 |
| **P1** | **约束形式化与可验证排程** | **非 NL2SQL**：用户/日历约束的 CSP/SMT 形式化、排程可验证性；与 VLDB/ICDE 约束与验证、形式化方法结合。 |
| **P1** | **长期模糊任务规划** | **非 NL2SQL**：模糊长期目标的分解、细化与排程；与 ICAPS/AAAI 规划社区衔接。 |
| **P1** | **Agent + Database 的安全与 MCP 标准化** | **非 NL2SQL**：写库安全、审计、MCP 与 DB 上下文的协议；适合 VLDB/SIGMOD 安全/系统 track。 |
| **P1** | **丰富自然语言操作到数据库操作的分解与映射（强调写/改）** | 与 NL2SQL 的“查询分解”**对比**，主打 **write/update 的分解与一致性**，不做“单次 SELECT 生成”；适合 VLDB/SIGMOD + NLP。 |

### 9.2 支撑方向（可与 NL2SQL 作相关 work，不主打）

| 优先级 | 科研问题 | 说明 |
|--------|----------|------|
| **P2** | 自然语言时间表达式 → 规范时间的基准与模型 | 可复用 TIME 等；支撑排程与约束，不主打 NL2SQL。 |
| **P2** | 从用户修正/隐式反馈做持续改进（RLUF / preference） | 支撑个性化与写操作后的学习；可与 WildFeedback 等对比。 |
| **P2** | 任务型对话 + 实体链接 + 工具调用的端到端基准 | 可包含“写操作 + 状态一致性”的评估，与 NL2SQL benchmark 区分。 |
| **P2** | Agent 的 grounding / recovery / calibration 评估 | 支撑“操作落地”与“幻觉归因”；SeekBench 等作相关 work。 |
| **P2** | 可解释性与信任的实证研究 | 与 planning_reason、用户采纳结合；HCI + NLP。 |
| **—** | NL2SQL/Agent+DB 的终身学习与 workload 适应 | **仅作相关 work**：RubikSQL、TailorSQL 等；不主打。 |
| **—** | DBMS–LLM 集成：结构化输出、资源与查询规划 | **仅作相关 work**：VLDB AIDB 等；若做系统向可轻量涉及，不主打“查询生成”。 |

---

## 十、相关文献与基准（便于开题与相关工作）

- **Agent 评估与基准**：Evaluation and Benchmarking of LLM Agents (survey, 2025)；SeekBench (epistemic competence)。  
- **幻觉与归因**：AgentHallu (tool-use hallucination attribution)；MIRAGE-Bench；HalluLens；FACTS Grounding。  
- **用户反馈与偏好**：RLUF；WildFeedback；Pref-GUIDE；Test-Time Preference Optimization。  
- **时间推理**：TIME benchmark (NeurIPS 2025 Spotlight)；Test of Time；TIMEBENCH。  
- **多步推理与检索**：MIRAGE (multi-hop interleaved RAG)。  
- **Agent + Database**：Spider 2.0 (ICLR 2025)；Bird-Interact (multi-turn, CRUD)；Bird；UNITE；I-Confluence (semantic errors in transactions)；BridgeScope (CRUD tools, ACID)。  
- **VLDB 2025–2026**：AIDB workshop (RDBMS for LLM queries, TailorSQL, MageSQL, Grounding LLMs for DB Exploration)；GuideAI (DBMS–LLM 集成架构)；RubikSQL (VLDB 2026 投稿, RubikBench)。  
- **SIGMOD 2025–2026**：λ-Tune；LLM4Hint；SEFRQO (SIGMOD 2026)；GPTuner；QUITE (query rewrite with LLM agents)。  
- **ICDE / CIDR / TKDE**：SWAN (beyond-database QA)；TKDE 2025 下一代数据库接口综述。  
- **数据库社区/大佬**：Michael Stonebraker & Andy Pavlo, “Data 2025: Year in Review” (PostgreSQL 官方/DBOS 等)；Agentic Postgres (agenticpostgres.org)；DBOS (dbos.dev)。  
- **补充方向（§8）**：View maintenance（VLDB/SIGMOD 经典方向）；MCP (Model Context Protocol)；行为序列/实时推荐（RecSys、KDD）；长期规划与约束（ICAPS、AAAI、SMT/CSP）。  

（具体引用格式可按投稿会议/期刊要求再补。）

---

## 十一、文档迭代

- 本文档随 demo 演进与社区热点更新，可增删问题、调整优先级与相关 work。
- 若某问题已形成论文或基准，可在文档中标注并链到论文/代码。
- **Agent + Database** 专题（§7）可单独扩展为「NL2DB / CRUD Agent」综述或开题章节。
- **补充科研问题**（§8）涵盖：操作–DB 匹配、安全与 MCP、用户行为与反思、行为序列→未来行为（非传统推荐）、实时推荐、长期模糊规划、影响传播与视图维护、约束形式化；可按投稿目标会议（VLDB/SIGMOD/RecSys/KDD/ICAPS 等）选取对应子方向。
