# Detailed Analysis: Last Two Execution Cases

This document provides a deep dive into the interaction and action flow of the last two cases recorded on 2026-03-09.

---

## Case 27: "读论文前去买菜"
**Timestamp:** 2026-03-09 19:02:50 - 19:04:30

### 1. Interaction Flow (Agent Rounds)
- **User Command**: "读论文前去买菜"
- **Round 1 (Information Gathering)**:
    - **Thought**: Need to find the "读论文" task to determine its current timing and dependencies.
    - **Tool Call**: `search_tasks` (关键词任务搜索：按标题关键词在数据库中查找匹配的任务)
    - **Result**: Found task `bad03c30` ("读论文"), current time: `11:00-12:00`.
- **Round 2 (Planning)**:
    - **Thought**: Insert a "买菜" task (30 min) and set "读论文" to follow it.
    - **Output**: `mutate` intent with two plan nodes:
        1. `insert` "买菜" (node_1).
        2. `update` "读论文" (target `bad03c30`), `depends_on`: `node_1`.

### 2. Action Pipeline & Supervision
- **1. 规划层监督 (Critic)**：LLM 在生成方案后，内部 `_run_openai_plan_critic` 确认了“先买菜再读论文”逻辑符合用户“读论文前”的要求。
- **2. 准入层核验 (Trust Gate)**：`evaluate_plan_trust` 检查发现“买菜”是新任务且目标任务“读论文”已通过 UUID 定位，允许进入写入流程。
- **3. 执行层状态机 (Action State Machine)**：
  - **Action 1 (Insert 买菜)**：执行前自动对受影响日期生成 **Snapshot** (快照)；`run_action_step` 执行插入，随即进行 **Post-Verify** 确认任务已成功进入 Supabase，核验通过。
  - **Action 2 (Update 读论文)**：执行更新并触发 `run_domino` (多米诺冲突自动平移)。原本 `11:00-12:00` 的任务因冲突被推移至 `12:00-13:00`。
  - **最终核验**：系统读取更新后的全天日程，确认无重叠冲突，完成流水线。

---

## Case 28: "安排睡觉时间"
**Timestamp:** 2026-03-09 19:45:06

### 1. Interaction Flow (Agent Rounds)
- **User Command**: "安排睡觉时间"
- **Round 1 (Context Gathering)**:
    - **Thought**: Need to see the current full schedule to find the last task of the day.
    - **Tool Call**: `get_tasks_for_date` (日期任务获取：从数据库检索指定日期的所有日程，用于构建时间上下文)
    - **Result**: Received list of 9 tasks. The latest task is "看电视" (`5c9945a5`), ending at `14:00` (Wait, the log says 14:00 but reasoning says 22:00? The user might have meant evening 9 PM / 21:00 based on previous logs).
- **Round 2 (Final Planning)**:
    - **Thought**: The last task ends late evening. I'll schedule "睡觉" (8 hours) to start after "看电视".
    - **Output**: `mutate` intent to `insert` "睡觉" with `depends_on`: `5c9945a5` and `estimated_minutes`: 480.

### 2. Action Pipeline & Supervision
- **规划层**：模型通过 `get_tasks_for_date` 获取了全天快照，定位到最后任务为“看电视”，据此建立 `depends_on` 依赖。
- **准入层**：核验通过，确认无重复的“睡觉”任务或逻辑死循环。
- **执行层 (State Machine)**：
  - **写入阶段**：预先保存 **Snapshot** (快照) 备份当前日程状态，然后执行插入“睡觉”任务（8小时）。
  - **核验阶段**：`verify_with_repair_fn` 重新拉取日程，确认“睡觉”已挂载在“看电视”结束时间之后，状态标记为 `ok`，本次回退机制未触发。

---

## 🏗️ 架构解析：DAG (有向无环图) 的应用

系统中广泛使用了 **DAG (Directed Acyclic Graph)** 模式，主要体现在以下两个环节：

### 1. 意图表达 (Intent Representation)
在 `ai/graph_models.py` 中，LLM 不输出孤立的时间点，而是输出包含 `depends_on` (依赖关系) 的 `DAGNode`。
- **作用**：将用户的自然语言（如“做完 A 后做 B”）直接通过图结构表达，避免在 LLM 层面进行复杂的时间计算。
- **优点**：即使 A 的时间发生变动，B 的相对逻辑顺序依然保持。

### 2. 拓扑排序与时间传播 (Topological Sorting)
在 `logic/graph_solver.py` 的 `resolve_graph_intent` 函数中，系统对接收到的任务图进行 **拓扑排序** (Topological Sort)。
- **操作流**：先处理没有任何依赖的任务（入度为 0），确定其绝对时间，然后将该时间顺着依赖边“传播”给后续任务。
- **结果**：将抽象的图结构扁平化为带具体 ISO 时间戳的线性执行序列。

### 3. 多米诺排程 (Domino Scheduling)
虽然 `run_domino` 涉及线性推挤，但它本质上也是在处理时间维度上的逻辑依赖，确保整个日程网络不出现重叠空隙或冲突。

---

## 🛡️ 执行监控：多层级“监督-核验”机制

针对 Action 执行过程，系统设计了从“大脑”到“肌肉”的三层监督状态：

### 1. 规划层监督 (Planning Critic)
在 `ai/agent.py` 中，LLM 产出计划后，会触发 `_run_openai_plan_critic`。
- **作用**：让模型以“审查者”身份对自己的 `GraphIntent` 进行二次检查（Self-Reflection），确保逻辑不违背常识。

### 2. 准入层核验 (Plan Trust Gate)
在 `service/plan_trust_gate.py` 中，执行前会通过 `evaluate_plan_trust` 进行硬规则过滤。
- **核心校验**：
    - **低信号过滤**：若 LLM 原始输出过于混乱导致“编译器”修复信号过低，禁止写入。
    - **逻辑冲突**：防止重复新增已定位到的同名任务，强制要求处理“已有事实”。

### 3. 执行层状态机 (Action State Machine)
在 `service/action_state_machine.py` 中，每一步 Action (`run_action_step`) 都遵循严格的生存周期：
- **Pre-Validate (预校验)**：写入前最后一次确定性环境检查。
- **Execute (执行写入)**：执行具体的 DB 变更。
- **Post-Verify (后置核验)**：**这是最关键的监督状态**。系统会重新读取数据库，对比“预期状态”与“实际状态”。若不符，支持自动 repair。
- **Rollback (自动回滚)**：若核验失败且无法修复，系统会根据执行前保存的 **Snapshot (快照)** 触发 `_restore_tasks_from_scope_snapshot`。
    - **逻辑**：删除动作中新增的任务，并将被修改的任务还原回快照中的原始状态（时间、备注、优先级等）。

---

## Technical Summary
- **Graph-Based Intent**: Instead of hardcoding times, the agent uses `depends_on` to let the `scheduler` handle the precise placement.
- **Self-Correction**: The Action Compiler bridges the gap between high-level LLM nodes and precise DB-ready actions.
- **Context Awareness**: `get_tasks_for_date` is critical for the agent to understand the "neighboring" tasks and avoid blindly overwriting the schedule.
