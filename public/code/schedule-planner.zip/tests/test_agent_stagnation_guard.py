import os
import sys
import types

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Optional deps stubs
if "dateparser" not in sys.modules:
    _dp = types.ModuleType("dateparser")
    _dp.parse = lambda *args, **kwargs: None
    sys.modules["dateparser"] = _dp

if "fuzzywuzzy" not in sys.modules:
    _fz = types.ModuleType("fuzzywuzzy")

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules["fuzzywuzzy"] = _fz

from ai.agent import _detect_tool_stagnation


def test_stagnation_guard_triggers_on_repeat():
    last = None
    repeat = 0
    last, repeat, force = _detect_tool_stagnation(last, repeat, ["a:{}"], threshold=2)
    assert force is False
    last, repeat, force = _detect_tool_stagnation(last, repeat, ["a:{}"], threshold=2)
    assert force is True
    print("test_stagnation_guard_triggers_on_repeat passed")


def test_stagnation_guard_resets_on_new_signature():
    last = None
    repeat = 0
    last, repeat, force = _detect_tool_stagnation(last, repeat, ["a:{}"], threshold=2)
    assert force is False
    last, repeat, force = _detect_tool_stagnation(last, repeat, ["b:{}"], threshold=2)
    assert force is False
    assert repeat == 1
    print("test_stagnation_guard_resets_on_new_signature passed")


if __name__ == "__main__":
    test_stagnation_guard_triggers_on_repeat()
    test_stagnation_guard_resets_on_new_signature()
    print("ALL agent stagnation guard tests passed")
