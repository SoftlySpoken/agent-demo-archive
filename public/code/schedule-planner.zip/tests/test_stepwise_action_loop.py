import sys
import os
import types
from datetime import date, datetime
from unittest.mock import patch, MagicMock

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Optional deps stubs
if 'dateparser' not in sys.modules:
    _dp = types.ModuleType('dateparser')
    _dp.parse = lambda *args, **kwargs: None
    sys.modules['dateparser'] = _dp

if 'fuzzywuzzy' not in sys.modules:
    _fz = types.ModuleType('fuzzywuzzy')
    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0
    _fz.fuzz = _Fuzz()
    sys.modules['fuzzywuzzy'] = _fz

from ai.models import CommandIntent
from ai.graph_models import GraphIntent, DAGNode
from db.models import Task
from service.app_service import (
    handle_user_command,
    _validate_single_action_step,
    _verify_single_action_step_effect,
    _verify_step_with_repair,
    _WRITE_FINGERPRINT_CACHE,
)
from logic.graph_solver import resolve_graph_intent


def _mk_task(tid: str, day: str, st: str, et: str, title: str):
    return Task(
        id=tid,
        title=title,
        start_time=f'{day}T{st}+00:00',
        end_time=f'{day}T{et}+00:00',
        priority='normal',
        status='pending',
        is_fixed=False,
    )


def test_validate_single_action_step_blocks_dependency_conflict():
    day = date.today()
    dep = _mk_task('d264eed8-7619-458a-a1d8-1851a1a13897', day.isoformat(), '09:00:00', '10:00:00', '跑步')
    action = {
        'action': 'insert',
        'title': '找朋友',
        'depends_on': ['d264eed8-7619-458a-a1d8-1851a1a13897'],
        'start_iso': f'{day.isoformat()}T09:30:00',
        'end_iso': f'{day.isoformat()}T10:00:00',
    }
    ok, msg = _validate_single_action_step(action, day, [dep])
    assert ok is False
    assert '依赖顺序不满足' in msg
    print('test_validate_single_action_step_blocks_dependency_conflict passed')


def test_handle_user_command_blocks_unresolved_dependency_before_write():
    _WRITE_FINGERPRINT_CACHE.clear()
    day = date.today().isoformat()
    existing = _mk_task('d264eed8-7619-458a-a1d8-1851a1a13897', day, '09:00:00', '10:00:00', '跑步')

    cmd = CommandIntent(
        intent='plan',
        actions=[
            {
                'action': 'insert',
                'title': '找朋友',
                'depends_on': ['d264eed8'],
                'unresolved_dependency': 'd264eed8',
                'duration_minutes': 30,
            }
        ],
        reply_text='测试',
        planning_reason='测试依赖解析失败场景',
    )

    with patch('config.USE_AGENT_MODE', False), \
         patch('service.app_service.parse_user_command', return_value=cmd), \
         patch('service.app_service.apply_guardrails', side_effect=lambda c, *_args, **_kwargs: c), \
         patch('service.app_service._prevalidate_actions', return_value=(True, '', 0)), \
         patch('service.app_service.repo') as mock_repo:

        mock_repo.tasks_for_date.return_value = [existing]
        mock_repo.save_snapshot.return_value = None
        mock_repo.insert_task = MagicMock()
        mock_repo.update_task.return_value = existing

        reply, warn, plan, reasoning = handle_user_command('跑步前找朋友')

    assert '校验失败' in reply
    assert plan is None
    assert not mock_repo.insert_task.called
    print('test_handle_user_command_blocks_unresolved_dependency_before_write passed')


def test_graph_solver_keeps_unresolved_dependency_without_now_fallback():
    today = date.today()
    graph = GraphIntent(
        intent='mutate',
        reasoning='测试',
        reply_text='测试',
        nodes=[
            DAGNode(
                id='node_1',
                action='insert',
                title='找朋友',
                estimated_minutes=30,
                depends_on=['unknown_dep'],
            )
        ],
    )
    cmd = resolve_graph_intent(graph, today, [], datetime.now().replace(microsecond=0))
    assert isinstance(cmd.actions, list) and len(cmd.actions) == 1
    a = cmd.actions[0]
    assert a.get('unresolved_dependency') == 'unknown_dep'
    assert a.get('start_iso') is None
    print('test_graph_solver_keeps_unresolved_dependency_without_now_fallback passed')


def test_graph_solver_resolves_target_id_without_title():
    today = date.today()
    day = today.isoformat()
    existing = _mk_task('d264eed8-7619-458a-a1d8-1851a1a13897', day, '09:00:00', '10:00:00', '组会')
    graph = GraphIntent(
        intent='mutate',
        reasoning='测试',
        reply_text='测试',
        nodes=[
            DAGNode(
                id='node_1',
                action='update',
                title='',
                target_id='d264eed8',
            )
        ],
    )
    cmd = resolve_graph_intent(graph, today, [existing], datetime.now().replace(microsecond=0))
    assert isinstance(cmd.actions, list) and len(cmd.actions) == 1
    a = cmd.actions[0]
    assert a.get('target_task_id') == 'd264eed8-7619-458a-a1d8-1851a1a13897'
    assert a.get('title') == '组会'
    expected_start = datetime.fromisoformat(existing.start_time.replace('Z', '+00:00')).astimezone().replace(tzinfo=None, microsecond=0).strftime('%Y-%m-%dT%H:%M:%S')
    expected_end = datetime.fromisoformat(existing.end_time.replace('Z', '+00:00')).astimezone().replace(tzinfo=None, microsecond=0).strftime('%Y-%m-%dT%H:%M:%S')
    assert a.get('start_iso') == expected_start
    assert a.get('end_iso') == expected_end
    assert a.get('new_start_iso') == expected_start
    assert a.get('new_end_iso') == expected_end
    print('test_graph_solver_resolves_target_id_without_title passed')


def test_graph_solver_orders_internal_dependency_and_drops_node_ref():
    today = date.today()
    day = today.isoformat()
    now_dt = datetime.now().replace(microsecond=0, second=0)
    existing = _mk_task('bad03c30-f213-4296-80d0-a6fb6d650da8', day, '11:00:00', '12:00:00', '读论文')
    graph = GraphIntent(
        intent='mutate',
        reasoning='测试',
        reply_text='测试',
        nodes=[
            DAGNode(
                id='node_1',
                action='insert',
                title='吃维生素D',
                estimated_minutes=15,
                time_constraint=f'{day}T10:30:00',
            ),
            DAGNode(
                id='node_2',
                action='update',
                title='',
                target_id='bad03c30-f213-4296-80d0-a6fb6d650da8',
                depends_on=['node_1'],
            ),
        ],
    )
    cmd = resolve_graph_intent(graph, today, [existing], now_dt)
    assert isinstance(cmd.actions, list) and len(cmd.actions) == 2
    first, second = cmd.actions[0], cmd.actions[1]
    assert first.get('action') == 'insert'
    assert second.get('action') == 'update'
    assert second.get('target_task_id') == 'bad03c30-f213-4296-80d0-a6fb6d650da8'
    assert second.get('unresolved_dependency') is None
    assert second.get('depends_on') == []
    assert second.get('title') == '读论文'
    assert second.get('start_iso') is not None and second.get('end_iso') is not None
    print('test_graph_solver_orders_internal_dependency_and_drops_node_ref passed')


def test_graph_solver_cycle_fails_fast_with_clarification():
    today = date.today()
    graph = GraphIntent(
        intent='mutate',
        reasoning='测试',
        reply_text='',
        nodes=[
            DAGNode(id='node_1', action='insert', title='A', depends_on=['node_2']),
            DAGNode(id='node_2', action='insert', title='B', depends_on=['node_1']),
        ],
    )
    cmd = resolve_graph_intent(graph, today, [], datetime.now().replace(microsecond=0))
    assert cmd.need_clarification is True
    assert cmd.actions == []
    assert '依赖' in (cmd.clarification_question or '')
    print('test_graph_solver_cycle_fails_fast_with_clarification passed')


def test_validate_single_action_step_blocks_update_without_mutation():
    day = date.today()
    task = _mk_task('task-1', day.isoformat(), '09:00:00', '10:00:00', '组会')
    action = {
        'action': 'update',
        'target_task_id': 'task-1',
    }
    ok, msg = _validate_single_action_step(action, day, [task])
    assert ok is False
    assert '缺少明确变更字段' in msg
    print('test_validate_single_action_step_blocks_update_without_mutation passed')


def test_verify_single_action_step_effect_requires_target_change():
    day = date.today().isoformat()
    before = [
        _mk_task('task-1', day, '09:00:00', '10:00:00', '组会'),
        _mk_task('task-2', day, '10:00:00', '11:00:00', '跑步'),
    ]
    after = [
        _mk_task('task-1', day, '09:00:00', '10:00:00', '组会'),
        _mk_task('task-2', day, '11:00:00', '12:00:00', '跑步'),
    ]
    ok, msg = _verify_single_action_step_effect(
        {
            'action': 'update',
            'target_task_id': 'task-1',
            'new_start_iso': f'{day}T09:30:00',
            'new_end_iso': f'{day}T10:30:00',
        },
        before,
        after,
    )
    assert ok is False
    assert '目标任务未发生变化' in msg
    print('test_verify_single_action_step_effect_requires_target_change passed')


def test_verify_step_with_repair_can_reach_expected_state():
    day = date.today()
    day_s = day.isoformat()
    before = [_mk_task('task-1', day_s, '09:00:00', '10:00:00', '组会')]
    after_wrong = [_mk_task('task-1', day_s, '09:00:00', '10:00:00', '组会')]
    after_repaired = [_mk_task('task-1', day_s, '09:30:00', '10:30:00', '组会')]

    action = {
        'action': 'update',
        'target_task_id': 'task-1',
        'new_start_iso': f'{day_s}T09:30:00',
        'new_end_iso': f'{day_s}T10:30:00',
    }

    with patch('service.app_service.repo.update_task', return_value=after_repaired[0]) as mock_update, \
         patch('service.app_service.repo.tasks_for_date', return_value=after_repaired):
        ok, msg, after_final = _verify_step_with_repair(action, before, after_wrong, day)

    assert ok is True
    assert msg == ''
    assert len(after_final) == 1
    assert after_final[0].start_time.endswith('09:30:00+00:00')
    assert mock_update.called
    print('test_verify_step_with_repair_can_reach_expected_state passed')


if __name__ == '__main__':
    test_validate_single_action_step_blocks_dependency_conflict()
    test_handle_user_command_blocks_unresolved_dependency_before_write()
    test_graph_solver_keeps_unresolved_dependency_without_now_fallback()
    test_graph_solver_resolves_target_id_without_title()
    test_graph_solver_orders_internal_dependency_and_drops_node_ref()
    test_graph_solver_cycle_fails_fast_with_clarification()
    test_validate_single_action_step_blocks_update_without_mutation()
    test_verify_single_action_step_effect_requires_target_change()
    test_verify_step_with_repair_can_reach_expected_state()
    print('ALL stepwise action loop tests passed')
