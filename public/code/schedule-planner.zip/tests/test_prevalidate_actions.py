import sys
import os
import types
from datetime import date
from unittest.mock import patch

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# 轻量依赖兜底：本地测试环境可能未安装 dateparser/fuzzywuzzy。
if "dateparser" not in sys.modules:
    _dp = types.ModuleType("dateparser")
    _dp.parse = lambda *args, **kwargs: None
    sys.modules["dateparser"] = _dp

if "fuzzywuzzy" not in sys.modules:
    _fz = types.ModuleType("fuzzywuzzy")
    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0
    _fz.fuzz = _Fuzz()
    sys.modules["fuzzywuzzy"] = _fz

from db.models import Task
from service.app_service import _prevalidate_actions


def test_prevalidate_blocks_hard_errors():
    actions = [
        {
            'action': 'update',
            'target_task_id': 'not-exists',
            'new_start_iso': '2026-03-08T11:00:00',
            'new_end_iso': '2026-03-08T10:00:00',  # invalid: end <= start
        }
    ]
    with patch('ai.tools.repo.tasks_for_date', return_value=[]):
        ok, msg, conflict_count = _prevalidate_actions(actions, date(2026, 3, 8))

    assert ok is False
    assert '计划校验未通过' in msg
    assert conflict_count == 0
    print('test_prevalidate_blocks_hard_errors passed')


def test_prevalidate_allows_conflicts_for_domino():
    existing = [
        Task(
            id='task-1',
            title='已有任务',
            start_time='2026-03-08T10:00:00+00:00',
            end_time='2026-03-08T11:00:00+00:00',
            priority='normal',
            status='pending',
            is_fixed=False,
        )
    ]
    actions = [
        {
            'action': 'insert',
            'title': '新任务',
            'start_iso': '2026-03-08T10:30:00+00:00',
            'end_iso': '2026-03-08T10:50:00+00:00',  # conflict with existing
        }
    ]
    with patch('ai.tools.repo.tasks_for_date', return_value=existing):
        ok, msg, conflict_count = _prevalidate_actions(actions, date(2026, 3, 8))

    assert ok is True
    assert msg == ''
    assert conflict_count > 0
    print('test_prevalidate_allows_conflicts_for_domino passed')


if __name__ == '__main__':
    test_prevalidate_blocks_hard_errors()
    test_prevalidate_allows_conflicts_for_domino()
    print('ALL prevalidate tests passed')
