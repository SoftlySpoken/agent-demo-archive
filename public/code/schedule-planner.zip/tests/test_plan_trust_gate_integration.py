import os
import sys
import types
from datetime import datetime
from unittest.mock import patch, MagicMock

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

if "dateparser" not in sys.modules:
    _dp = types.ModuleType("dateparser")
    _dp.parse = lambda *args, **kwargs: None
    sys.modules["dateparser"] = _dp

if "fuzzywuzzy" not in sys.modules:
    _fz = types.ModuleType("fuzzywuzzy")

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules["fuzzywuzzy"] = _fz

from ai.models import CommandIntent
from db.models import Task
from service.command_pipeline import PipelineResult
from service.app_service import handle_user_command


def test_plan_trust_gate_blocks_compiler_duplicate_insert():
    cmd = CommandIntent(
        intent="plan",
        actions=[
            {"action": "insert", "title": "读论文"},
            {"action": "insert", "title": "吃维生素D"},
        ],
        reply_text="ok",
        parse_source="agent_resolved",
    )
    pipeline_out = PipelineResult(
        cmd=cmd,
        reasoning="[AGENT] test",
        source="agent",
        agent_meta={
            "compiler_repaired": True,
            "compiler_repair_low_signal": True,
            "tool_facts": {
                "tasks_by_title": {
                    "读论文": [{"id": "task-paper-1", "title": "读论文"}]
                }
            },
        },
    )
    existing = Task(
        id="task-paper-1",
        title="读论文",
        start_time="2026-03-09T11:00:00+00:00",
        end_time="2026-03-09T12:00:00+00:00",
        priority="normal",
        status="pending",
        is_fixed=False,
    )
    with patch("service.app_service.run_command_pipeline", return_value=pipeline_out), patch(
        "service.app_service.repo.tasks_for_date", return_value=[existing]
    ):
        reply, warn, plan, _ = handle_user_command("读论文前吃维生素D")
    assert "计划可信度校验未通过" in reply
    assert warn is None
    assert plan is None


def test_agent_only_write_mode_blocks_legacy_write():
    cmd = CommandIntent(
        intent="insert",
        actions=[
            {
                "action": "insert",
                "title": "跑步",
                "start_iso": "2026-03-09T20:00:00",
                "end_iso": "2026-03-09T21:00:00",
            }
        ],
        parse_source="llm",
        reply_text="legacy",
    )
    pipeline_out = PipelineResult(
        cmd=cmd,
        reasoning="[LEGACY] test",
        source="legacy",
        agent_meta={"protocol_failed": False},
    )
    with patch("config.USE_AGENT_MODE", True), patch(
        "service.app_service.AGENT_ONLY_WRITE_MODE", True
    ), patch("service.app_service.run_command_pipeline", return_value=pipeline_out), patch(
        "service.app_service.repo.tasks_for_date", return_value=[]
    ), patch("service.app_service.repo.insert_task", new=MagicMock()):
        reply, warn, plan, _ = handle_user_command("新增跑步")
    assert "仅 agent 协议成功可写库" in reply
    assert warn is None
    assert plan is None

