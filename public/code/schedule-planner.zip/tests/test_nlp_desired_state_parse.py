import sys
import os
import types
from datetime import date

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Test env stubs for optional deps
if 'dateparser' not in sys.modules:
    _dp = types.ModuleType('dateparser')
    _dp.parse = lambda *args, **kwargs: None
    sys.modules['dateparser'] = _dp

if 'fuzzywuzzy' not in sys.modules:
    _fz = types.ModuleType('fuzzywuzzy')
    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0
    _fz.fuzz = _Fuzz()
    sys.modules['fuzzywuzzy'] = _fz

from ai.nlp import _dict_to_intent


def test_dict_to_intent_with_desired_state():
    obj = {
        'intent': 'plan',
        'planning_reason': '按优先级重排',
        'desired_state': [
            {
                'id': 'task-1',
                'title': '组会',
                'start_iso': '2026-03-08T10:00:00',
                'end_iso': '2026-03-08T11:00:00',
                'priority': 'high',
                'status': 'pending',
                'is_fixed': False,
            },
            {
                'title': '跑步',
                'start_iso': '2026-03-08T11:30:00',
                'end_iso': '2026-03-08T12:00:00',
            },
        ],
        'reply_text': '已为你规划目标日程',
        'reasoning': '先重要后次要',
    }
    cmd = _dict_to_intent(obj, date(2026, 3, 8), '请帮我重排')
    assert cmd.intent == 'plan'
    assert cmd.desired_state is not None
    assert len(cmd.desired_state) == 2
    assert cmd.desired_state[0]['id'] == 'task-1'
    assert cmd.desired_state[1]['title'] == '跑步'
    print('test_dict_to_intent_with_desired_state passed')


def test_dict_to_intent_update_does_not_invent_delta():
    obj = {
        'intent': 'update',
        'actions': [
            {
                'action': 'update',
                'target_title': '组会',
            }
        ],
    }
    cmd = _dict_to_intent(obj, date(2026, 3, 8), '把组会往后挪一下')
    assert isinstance(cmd.actions, list) and len(cmd.actions) == 1
    assert 'delta_minutes' not in cmd.actions[0]
    print('test_dict_to_intent_update_does_not_invent_delta passed')


if __name__ == '__main__':
    test_dict_to_intent_with_desired_state()
    test_dict_to_intent_update_does_not_invent_delta()
    print('ALL nlp desired_state parse tests passed')
