import os
import sys
import tempfile
import time

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from utils.idempotency_store import PersistentIdempotencyStore


def test_persistent_idem_store_survives_recreate():
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "idem.json")
        s1 = PersistentIdempotencyStore(path=path, ttl_seconds=60, max_entries=64)
        s1.mark("k1", now_ts=100.0)
        assert s1.is_recent("k1", now_ts=120.0) is True

        # Recreate store instance to simulate process restart.
        s2 = PersistentIdempotencyStore(path=path, ttl_seconds=60, max_entries=64)
        assert s2.is_recent("k1", now_ts=130.0) is True
    print("test_persistent_idem_store_survives_recreate passed")


def test_persistent_idem_store_ttl_expire():
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "idem.json")
        s = PersistentIdempotencyStore(path=path, ttl_seconds=10, max_entries=64)
        s.mark("k1", now_ts=100.0)
        assert s.is_recent("k1", now_ts=109.0) is True
        assert s.is_recent("k1", now_ts=111.0) is False
    print("test_persistent_idem_store_ttl_expire passed")


if __name__ == "__main__":
    test_persistent_idem_store_survives_recreate()
    test_persistent_idem_store_ttl_expire()
    print("ALL idempotency store tests passed")

