import sys
import os
import types
from datetime import date, datetime

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Optional deps stubs
if 'dateparser' not in sys.modules:
    _dp = types.ModuleType('dateparser')
    _dp.parse = lambda *args, **kwargs: None
    sys.modules['dateparser'] = _dp

if 'fuzzywuzzy' not in sys.modules:
    _fz = types.ModuleType('fuzzywuzzy')
    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0
    _fz.fuzz = _Fuzz()
    sys.modules['fuzzywuzzy'] = _fz

from ai.agent import _run_openai_format_agent


def _mk_resp(content: str):
    msg = types.SimpleNamespace(tool_calls=None, content=content)
    choice = types.SimpleNamespace(message=msg)
    return types.SimpleNamespace(choices=[choice])


class _FakeCompletions:
    def __init__(self, responses):
        self._responses = responses
        self.calls = 0

    def create(self, **_kwargs):
        idx = self.calls
        self.calls += 1
        if idx >= len(self._responses):
            idx = len(self._responses) - 1
        return self._responses[idx]


class _FakeClient:
    def __init__(self, responses):
        self.chat = types.SimpleNamespace(completions=_FakeCompletions(responses))


def test_openai_format_agent_retries_invalid_final_answer():
    valid = '{"intent":"query","reasoning":"ok","reply_text":"ok","nodes":[],"need_clarification":false,"clarification_question":""}'
    client = _FakeClient([
        _mk_resp("```"),
        _mk_resp(valid),
    ])
    res, rounds = _run_openai_format_agent(
        client=client,
        model_name="fake-model",
        user_text="测试",
        today=date(2026, 3, 9),
        now_dt=datetime(2026, 3, 9, 1, 0, 0),
        max_rounds=3,
        conversation_history=None,
    )
    assert res is not None
    assert res.intent == "query"
    assert client.chat.completions.calls == 2
    assert any(r.get("invalid_final") for r in rounds if isinstance(r, dict))
    print('test_openai_format_agent_retries_invalid_final_answer passed')


def test_openai_format_agent_invalid_final_exhausts_rounds():
    client = _FakeClient([_mk_resp("```")])
    res, rounds = _run_openai_format_agent(
        client=client,
        model_name="fake-model",
        user_text="测试",
        today=date(2026, 3, 9),
        now_dt=datetime(2026, 3, 9, 1, 0, 0),
        max_rounds=1,
        conversation_history=None,
    )
    assert res is None
    assert client.chat.completions.calls == 1
    assert len(rounds) == 1 and rounds[0].get("invalid_final") is True
    print('test_openai_format_agent_invalid_final_exhausts_rounds passed')


def test_openai_format_agent_compiler_repairs_invalid_output():
    invalid = '{"intent":"mutate","reasoning":"x","reply_text":"x","nodes":[{"id":"n1","action":"update","target_id":"task-1"}]'
    valid = '{"intent":"mutate","reasoning":"ok","reply_text":"ok","need_clarification":false,"clarification_question":"","nodes":[{"id":"n1","action":"update","title":"task-1","target_id":"task-1","depends_on":[]}]}'
    client = _FakeClient([
        _mk_resp(invalid),  # planner final（无 title，不合法）
        _mk_resp(valid),    # compiler 修复输出
    ])
    res, rounds = _run_openai_format_agent(
        client=client,
        model_name="fake-model",
        user_text="测试",
        today=date(2026, 3, 9),
        now_dt=datetime(2026, 3, 9, 1, 0, 0),
        max_rounds=3,
        conversation_history=None,
    )
    assert res is not None
    assert res.intent == "mutate"
    assert client.chat.completions.calls == 2
    assert any(r.get("compiler_repaired") for r in rounds if isinstance(r, dict))
    print('test_openai_format_agent_compiler_repairs_invalid_output passed')


if __name__ == '__main__':
    test_openai_format_agent_retries_invalid_final_answer()
    test_openai_format_agent_invalid_final_exhausts_rounds()
    test_openai_format_agent_compiler_repairs_invalid_output()
    print('ALL agent finalize retry tests passed')
