from ai.protocol_translator import normalize_graph_protocol, translate_action, translate_intent


def test_translate_intent_and_action_synonyms():
    assert translate_intent("schedule_actions", has_nodes=True) == "mutate"
    assert translate_intent("search", has_nodes=False) == "query"
    assert translate_action("create") == "insert"
    assert translate_action("reschedule") == "update"


def test_normalize_graph_protocol_infers_action_when_missing():
    payload = {
        "intent": "mutation",
        "nodes": [
            {"id": "n1", "title": "跑步", "estimated_minutes": 30},
            {"id": "n2", "target_task_id": "abc", "new_start_iso": "2026-03-09T20:00:00"},
        ],
    }
    out = normalize_graph_protocol(payload)
    assert out["intent"] == "mutate"
    assert out["nodes"][0]["action"] == "insert"
    assert out["nodes"][1]["action"] == "update"
