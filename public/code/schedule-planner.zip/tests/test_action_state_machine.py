import os
import sys
import types
from datetime import date

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Optional deps stubs
if "dateparser" not in sys.modules:
    _dp = types.ModuleType("dateparser")
    _dp.parse = lambda *args, **kwargs: None
    sys.modules["dateparser"] = _dp

if "fuzzywuzzy" not in sys.modules:
    _fz = types.ModuleType("fuzzywuzzy")

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules["fuzzywuzzy"] = _fz

from db.models import Task
from service.action_state_machine import run_action_step


def _mk_task(tid: str) -> Task:
    return Task(
        id=tid,
        start_time="2026-03-09T01:00:00+00:00",
        end_time="2026-03-09T02:00:00+00:00",
        title="组会",
        priority="normal",
        status="pending",
        is_fixed=False,
    )


def test_action_state_machine_validate_fail_short_circuit():
    applied = {"count": 0}

    def fetch_scope(_action, _today):
        return [_mk_task("a")]

    def validate(_action, _today, _before):
        return False, "bad input"

    def apply_write():
        applied["count"] += 1

    def verify(_action, _before, _after, _today):
        return True, "", _after

    res = run_action_step(
        action={"action": "update"},
        today=date(2026, 3, 9),
        fetch_scope_tasks_fn=fetch_scope,
        validate_step_fn=validate,
        apply_write_fn=apply_write,
        verify_with_repair_fn=verify,
    )
    assert res.ok is False
    assert "bad input" in res.message
    assert applied["count"] == 0
    print("test_action_state_machine_validate_fail_short_circuit passed")


def test_action_state_machine_verify_fail_with_rollback():
    rolled = {"count": 0}

    def fetch_scope(_action, _today):
        return [_mk_task("a")]

    def validate(_action, _today, _before):
        return True, ""

    def apply_write():
        return None

    def verify(_action, _before, _after, _today):
        return False, "post check failed", _after

    def rollback():
        rolled["count"] += 1
        return 3

    res = run_action_step(
        action={"action": "update"},
        today=date(2026, 3, 9),
        fetch_scope_tasks_fn=fetch_scope,
        validate_step_fn=validate,
        apply_write_fn=apply_write,
        verify_with_repair_fn=verify,
        rollback_fn=rollback,
    )
    assert res.ok is False
    assert "post check failed" in res.message
    assert res.rolled_back_count == 3
    assert rolled["count"] == 1
    print("test_action_state_machine_verify_fail_with_rollback passed")


if __name__ == "__main__":
    test_action_state_machine_validate_fail_short_circuit()
    test_action_state_machine_verify_fail_with_rollback()
    print("ALL action state machine tests passed")
