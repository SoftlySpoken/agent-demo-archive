import sys
import os
import types
from datetime import date
from unittest.mock import patch

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

if "dateparser" not in sys.modules:
    _dp = types.ModuleType("dateparser")
    _dp.parse = lambda *args, **kwargs: None
    sys.modules["dateparser"] = _dp

if "fuzzywuzzy" not in sys.modules:
    _fz = types.ModuleType("fuzzywuzzy")

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules["fuzzywuzzy"] = _fz

from ai.models import CommandIntent
from service.command_pipeline import PipelineResult
from service.app_service import (
    _derive_semantic_contract_from_actions,
    _legacy_result_is_safe_after_protocol_failure,
    handle_user_command,
)


def test_legacy_protocol_failed_blocks_anchorless_write():
    cmd = CommandIntent(
        intent="insert",
        actions=[{"action": "insert", "title": "跑步"}],
        reply_text="legacy",
        parse_source="llm",
    )
    pipeline_out = PipelineResult(
        cmd=cmd,
        reasoning="[LEGACY] test",
        source="legacy",
        agent_meta={"protocol_failed": True},
    )
    with patch("service.app_service.repo.tasks_for_date", return_value=[]), \
         patch("service.app_service.run_command_pipeline", return_value=pipeline_out):
        reply, warn, pending, _reasoning = handle_user_command("跑步前找朋友")
    assert "模型输出格式不稳定" in reply
    assert warn is None
    assert pending is None
    print("test_legacy_protocol_failed_blocks_anchorless_write passed")


def test_legacy_protocol_failed_allows_anchored_write():
    cmd = CommandIntent(
        intent="update",
        actions=[{"action": "update", "target_task_id": "task-1", "new_start_iso": "2026-03-09T10:00:00", "new_end_iso": "2026-03-09T11:00:00"}],
        reply_text="legacy",
        parse_source="llm",
    )
    assert _legacy_result_is_safe_after_protocol_failure(cmd) is True
    print("test_legacy_protocol_failed_allows_anchored_write passed")


def test_rule_fallback_mutation_is_blocked():
    cmd = CommandIntent(
        intent="insert",
        actions=[{"action": "insert", "title": "跑步"}],
        reply_text="rule fallback",
        parse_source="rule_fallback",
    )
    pipeline_out = PipelineResult(
        cmd=cmd,
        reasoning="[LEGACY] fallback",
        source="legacy",
        agent_meta={},
    )
    with patch("service.app_service.repo.tasks_for_date", return_value=[]), \
         patch("service.app_service.run_command_pipeline", return_value=pipeline_out):
        reply, warn, pending, _reasoning = handle_user_command("新增跑步")
    assert "未获得可验证的结构化模型输出" in reply
    assert warn is None
    assert pending is None
    print("test_rule_fallback_mutation_is_blocked passed")


def test_derive_semantic_contract_from_actions_insert_update():
    actions = [
        {"action": "insert", "title": "找朋友"},
        {"action": "update", "target_task_id": "task-1", "new_start_iso": "2026-03-09T12:00:00", "new_end_iso": "2026-03-09T13:00:00"},
    ]
    contract = _derive_semantic_contract_from_actions(actions)
    assert isinstance(contract, list) and len(contract) == 2
    assert contract[0]["title"] == "找朋友"
    assert contract[1]["id"] == "task-1"
    print("test_derive_semantic_contract_from_actions_insert_update passed")


if __name__ == "__main__":
    test_legacy_protocol_failed_blocks_anchorless_write()
    test_legacy_protocol_failed_allows_anchored_write()
    test_rule_fallback_mutation_is_blocked()
    test_derive_semantic_contract_from_actions_insert_update()
    print("ALL protocol semantic guard tests passed")
