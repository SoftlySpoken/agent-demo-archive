import os
import sys
import types
from datetime import date, datetime
from unittest.mock import patch

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Optional deps stubs
if "dateparser" not in sys.modules:
    _dp = types.ModuleType("dateparser")
    _dp.parse = lambda *args, **kwargs: None
    sys.modules["dateparser"] = _dp

if "fuzzywuzzy" not in sys.modules:
    _fz = types.ModuleType("fuzzywuzzy")

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules["fuzzywuzzy"] = _fz

from ai.agent import _build_context_header, run_agent
from ai.nlp import _build_nlp_context_prompt
from db.models import Task


def test_run_agent_forces_no_conversation_history():
    seen = {"azure_history": "unset", "gemini_history": "unset"}
    call_order = []

    def _fake_azure(_text, _today, _now, _max_rounds, conversation_history=None):
        call_order.append("azure")
        seen["azure_history"] = conversation_history
        return None, []

    def _fake_gemini(_text, _today, _now, _max_rounds, conversation_history=None):
        call_order.append("gemini")
        seen["gemini_history"] = conversation_history
        return None, []

    with patch("ai.agent._run_azure_agent", side_effect=_fake_azure), \
         patch("ai.agent._run_gemini_agent", side_effect=_fake_gemini), \
         patch("ai.agent._log_agent_trace", return_value=None):
        res = run_agent(
            "测试",
            today=date(2026, 3, 9),
            now_dt=datetime(2026, 3, 9, 10, 0, 0),
            conversation_history=[{"role": "assistant", "content": "old"}],
        )

    assert res is None
    assert seen["azure_history"] is None
    assert seen["gemini_history"] is None
    assert call_order == ["gemini", "azure"]
    print("test_run_agent_forces_no_conversation_history passed")


def test_agent_context_header_can_disable_snapshot():
    with patch("ai.agent._build_task_snapshot", return_value="【今日关键任务快照】\n- dummy"):
        with_snapshot = _build_context_header(
            today=date(2026, 3, 9),
            now_dt=datetime(2026, 3, 9, 10, 0, 0),
            include_task_snapshot=True,
        )
        no_snapshot = _build_context_header(
            today=date(2026, 3, 9),
            now_dt=datetime(2026, 3, 9, 10, 0, 0),
            include_task_snapshot=False,
        )

    assert "今日关键任务快照" in with_snapshot
    assert "今日关键任务快照" not in no_snapshot
    assert "若信息不足，请先调用工具" in no_snapshot
    print("test_agent_context_header_can_disable_snapshot passed")


def test_nlp_context_prompt_can_be_stateless():
    tasks = [
        Task(
            id="task-1",
            title="组会",
            start_time="2026-03-09T09:00:00+00:00",
            end_time="2026-03-09T10:00:00+00:00",
            priority="normal",
            status="pending",
            is_fixed=False,
        )
    ]
    history = [{"role": "assistant", "content": "上一轮内容"}]

    stateless = _build_nlp_context_prompt(
        system_prompt="SCHEMA",
        today=date(2026, 3, 9),
        now_iso="2026-03-09T10:00:00",
        weekday="一",
        day_tasks=tasks,
        conversation_history=history,
        include_history=False,
        include_day_tasks=False,
    )
    with_ctx = _build_nlp_context_prompt(
        system_prompt="SCHEMA",
        today=date(2026, 3, 9),
        now_iso="2026-03-09T10:00:00",
        weekday="一",
        day_tasks=tasks,
        conversation_history=history,
        include_history=True,
        include_day_tasks=True,
    )

    assert "对话历史" not in stateless
    assert "当日已有任务概览" not in stateless
    assert "对话历史" in with_ctx
    assert "当日已有任务概览" in with_ctx
    assert "组会" in with_ctx
    print("test_nlp_context_prompt_can_be_stateless passed")


if __name__ == "__main__":
    test_run_agent_forces_no_conversation_history()
    test_agent_context_header_can_disable_snapshot()
    test_nlp_context_prompt_can_be_stateless()
    print("ALL stateless model boundary tests passed")
