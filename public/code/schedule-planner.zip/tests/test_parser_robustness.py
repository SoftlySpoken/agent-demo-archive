import sys
import os
import types
from datetime import date

# Add the root directory to sys.path to import from ai
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Optional deps stubs
if 'dateparser' not in sys.modules:
    _dp = types.ModuleType('dateparser')
    _dp.parse = lambda *args, **kwargs: None
    sys.modules['dateparser'] = _dp

if 'fuzzywuzzy' not in sys.modules:
    _fz = types.ModuleType('fuzzywuzzy')
    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0
    _fz.fuzz = _Fuzz()
    sys.modules['fuzzywuzzy'] = _fz

from ai.agent import _parse_agent_response

def test_parser():
    today = date(2026, 3, 8)
    user_text = "test"
    
    # Case 1: Pure JSON
    raw1 = '{"intent": "query", "reasoning": "thought", "reply_text": "hello", "nodes": []}'
    res1 = _parse_agent_response(raw1, today, user_text)
    assert res1 is not None and res1.intent == "query"
    print("Test Case 1 passed: Pure JSON")

    # Case 2: Markdown wrapped JSON
    raw2 = '```json\n{"intent": "mutate", "reasoning": "thought", "reply_text": "ok", "nodes": []}\n```'
    res2 = _parse_agent_response(raw2, today, user_text)
    assert res2 is not None and res2.intent == "mutate"
    print("Test Case 2 passed: Markdown wrapped")

    # Case 3: Text before JSON (Common failure case)
    raw3 = 'Here is the plan: {"intent": "query", "reasoning": "thought", "reply_text": "bye", "nodes": []}'
    res3 = _parse_agent_response(raw3, today, user_text)
    assert res3 is not None and res3.intent == "query"
    print("Test Case 3 passed: Text before JSON")

    # Case 4: Text after JSON
    raw4 = '{"intent": "mutate", "reasoning": "thought", "reply_text": "hi", "nodes": []} Hope this helps!'
    res4 = _parse_agent_response(raw4, today, user_text)
    assert res4 is not None and res4.intent == "mutate"
    print("Test Case 4 passed: Text after JSON")

    # Case 5: Complex nested blocks (should find the outermost one)
    raw5 = 'Thoughts... {"intent": "query", "reasoning": "{}", "reply_text": "nested", "nodes": []} ...end'
    res5 = _parse_agent_response(raw5, today, user_text)
    assert res5 is not None and res5.intent == "query"
    print("Test Case 5 passed: Nested blocks")

    # Case 6: Invalid JSON (should return None now, not a fake object)
    raw6 = 'Not a JSON at all'
    res6 = _parse_agent_response(raw6, today, user_text)
    assert res6 is None
    print("Test Case 6 passed: Invalid JSON returns None")

    # Case 7: time_constraint object should be normalized instead of failing whole parse
    raw7 = """
    {
      "intent": "mutate",
      "reasoning": "test",
      "reply_text": "ok",
      "need_clarification": false,
      "clarification_question": "",
      "nodes": [
        {
          "id": "node_1",
          "action": "insert",
          "title": "找朋友",
          "depends_on": [],
          "time_constraint": {
            "start_time": "2026-03-09T09:00:00",
            "end_time": "2026-03-09T10:00:00"
          }
        }
      ]
    }
    """
    res7 = _parse_agent_response(raw7, today, user_text)
    assert res7 is not None and res7.intent == "mutate"
    assert len(res7.nodes) == 1
    assert isinstance(res7.nodes[0].time_constraint, str)
    print("Test Case 7 passed: time_constraint object normalized")

    # Case 8: update 节点缺少 title，但有 target_id（应可解析）
    raw8 = """
    {
      "intent": "mutate",
      "reasoning": "test",
      "reply_text": "ok",
      "need_clarification": false,
      "clarification_question": "",
      "nodes": [
        {
          "id": "node_1",
          "action": "update",
          "target_id": "bad03c30-f213-4296-80d0-a6fb6d650da8"
        }
      ]
    }
    """
    res8 = _parse_agent_response(raw8, today, user_text)
    assert res8 is not None and res8.intent == "mutate"
    assert len(res8.nodes) == 1
    assert res8.nodes[0].target_id == "bad03c30-f213-4296-80d0-a6fb6d650da8"
    print("Test Case 8 passed: target_id without title normalized")

if __name__ == "__main__":
    try:
        test_parser()
        print("\nALL PARSER TESTS PASSED!")
    except Exception as e:
        print(f"\nTEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
