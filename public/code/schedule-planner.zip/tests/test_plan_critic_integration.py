import sys
import os
import types
from datetime import date
from unittest.mock import patch

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Optional deps stubs
if 'dateparser' not in sys.modules:
    _dp = types.ModuleType('dateparser')
    _dp.parse = lambda *args, **kwargs: None
    sys.modules['dateparser'] = _dp

if 'fuzzywuzzy' not in sys.modules:
    _fz = types.ModuleType('fuzzywuzzy')

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules['fuzzywuzzy'] = _fz

from ai.graph_models import GraphIntent, DAGNode
from ai.models import CommandIntent
from service.app_service import handle_user_command


def _mk_graph(dep: str) -> GraphIntent:
    return GraphIntent(
        intent='mutate',
        reasoning='测试',
        reply_text='测试',
        nodes=[
            DAGNode(
                id='n1',
                action='insert',
                title='找朋友',
                estimated_minutes=30,
                depends_on=[dep],
            )
        ],
    )


def test_handle_user_command_uses_plan_critic_when_enabled():
    base_graph = _mk_graph('old-dep')
    reviewed_graph = _mk_graph('new-dep')
    resolved = CommandIntent(
        intent='plan',
        actions=[],
        reply_text='ok',
    )

    with patch('config.USE_AGENT_MODE', True), \
         patch('config.PLAN_CRITIC_ENABLED', True), \
         patch('service.app_service.repo.tasks_for_date', return_value=[]), \
         patch('ai.agent.run_agent', return_value=base_graph), \
         patch('ai.agent.run_plan_critic', return_value=reviewed_graph) as mock_critic, \
         patch('logic.graph_solver.resolve_graph_intent', return_value=resolved) as mock_resolve:
        reply, warn, plan, reasoning = handle_user_command('跑步前找朋友')

    assert mock_critic.called
    called_graph = mock_resolve.call_args[0][0]
    assert called_graph.nodes[0].depends_on == ['new-dep']
    assert reasoning.startswith('[AGENT+CRITIC]')
    assert reply == 'ok'
    print('test_handle_user_command_uses_plan_critic_when_enabled passed')


def test_handle_user_command_skips_plan_critic_when_disabled():
    base_graph = _mk_graph('old-dep')
    resolved = CommandIntent(
        intent='plan',
        actions=[],
        reply_text='ok',
    )

    with patch('config.USE_AGENT_MODE', True), \
         patch('config.PLAN_CRITIC_ENABLED', False), \
         patch('service.app_service.repo.tasks_for_date', return_value=[]), \
         patch('ai.agent.run_agent', return_value=base_graph), \
         patch('ai.agent.run_plan_critic', return_value=None) as mock_critic, \
         patch('logic.graph_solver.resolve_graph_intent', return_value=resolved) as mock_resolve:
        reply, warn, plan, reasoning = handle_user_command('跑步前找朋友')

    assert not mock_critic.called
    called_graph = mock_resolve.call_args[0][0]
    assert called_graph.nodes[0].depends_on == ['old-dep']
    assert reasoning.startswith('[AGENT]')
    assert reply == 'ok'
    print('test_handle_user_command_skips_plan_critic_when_disabled passed')


if __name__ == '__main__':
    test_handle_user_command_uses_plan_critic_when_enabled()
    test_handle_user_command_skips_plan_critic_when_disabled()
    print('ALL plan critic integration tests passed')
