import os
import sys
import types
from datetime import date, datetime
from unittest.mock import patch

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Optional deps stubs
if "dateparser" not in sys.modules:
    _dp = types.ModuleType("dateparser")
    _dp.parse = lambda *args, **kwargs: None
    sys.modules["dateparser"] = _dp

if "fuzzywuzzy" not in sys.modules:
    _fz = types.ModuleType("fuzzywuzzy")

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules["fuzzywuzzy"] = _fz

from ai.models import CommandIntent
from db.models import Task
from service.command_pipeline import run_command_pipeline


class _Graph:
    def __init__(self, intent="mutate", reasoning="g"):
        self.intent = intent
        self.reasoning = reasoning
        self.nodes = []


def test_pipeline_agent_path_and_unified_normalize():
    calls = {"guardrails": 0, "normalize": 0, "parse": 0}

    def run_agent_fn(*_args, **_kwargs):
        return _Graph(intent="mutate", reasoning="agent reason")

    def run_plan_critic_fn(**_kwargs):
        return _Graph(intent="mutate", reasoning="critic reason")

    def resolve_graph_intent_fn(_graph, _today, _tasks, _now):
        return CommandIntent(intent="plan", actions=[{"action": "insert", "target_title_expr": "跑步"}])

    def parse_user_command_fn(*_args, **_kwargs):
        calls["parse"] += 1
        return CommandIntent(intent="query", reply_text="legacy")

    def apply_guardrails_fn(cmd, *_args, **_kwargs):
        calls["guardrails"] += 1
        return cmd

    def normalize_fn(cmd, *_args, **_kwargs):
        calls["normalize"] += 1
        if isinstance(cmd.actions, list):
            for a in cmd.actions:
                if isinstance(a, dict) and a.get("target_title_expr") and not a.get("title"):
                    a["title"] = a["target_title_expr"]
        return cmd

    out = run_command_pipeline(
        user_text="跑步前找朋友",
        today=date(2026, 3, 9),
        now_dt=datetime(2026, 3, 9, 10, 0, 0),
        day_tasks_for_ai=[],
        conversation_history=[{"role": "assistant", "content": "old"}],
        use_agent_mode=True,
        plan_critic_enabled=True,
        run_agent_fn=run_agent_fn,
        run_plan_critic_fn=run_plan_critic_fn,
        resolve_graph_intent_fn=resolve_graph_intent_fn,
        parse_user_command_fn=parse_user_command_fn,
        apply_guardrails_fn=apply_guardrails_fn,
        normalize_command_intent_fn=normalize_fn,
    )

    assert out.source == "agent"
    assert out.reasoning.startswith("[AGENT+CRITIC]")
    assert calls["parse"] == 0
    assert calls["guardrails"] == 1
    assert calls["normalize"] == 1
    assert out.cmd.actions[0]["title"] == "跑步"
    print("test_pipeline_agent_path_and_unified_normalize passed")


def test_pipeline_legacy_fallback_without_history():
    seen = {"conversation_history": "unset", "guardrails": 0, "normalize": 0}

    def run_agent_fn(*_args, **_kwargs):
        return None

    def run_plan_critic_fn(**_kwargs):
        return None

    def resolve_graph_intent_fn(*_args, **_kwargs):
        return CommandIntent(intent="query", reply_text="unused")

    def parse_user_command_fn(_user_text, _today, day_tasks=None, now_dt=None, conversation_history=None):
        seen["conversation_history"] = conversation_history
        assert isinstance(day_tasks, list)
        assert now_dt is not None
        return CommandIntent(intent="query", reply_text="legacy")

    def apply_guardrails_fn(cmd, *_args, **_kwargs):
        seen["guardrails"] += 1
        return cmd

    def normalize_fn(cmd, *_args, **_kwargs):
        seen["normalize"] += 1
        return cmd

    with patch("service.command_pipeline.AGENT_ONLY_WRITE_MODE", False):
        out = run_command_pipeline(
            user_text="今天干啥",
            today=date(2026, 3, 9),
            now_dt=datetime(2026, 3, 9, 10, 0, 0),
            day_tasks_for_ai=[],
            conversation_history=[{"role": "assistant", "content": "old"}],
            use_agent_mode=True,
            plan_critic_enabled=True,
            run_agent_fn=run_agent_fn,
            run_plan_critic_fn=run_plan_critic_fn,
            resolve_graph_intent_fn=resolve_graph_intent_fn,
            parse_user_command_fn=parse_user_command_fn,
            apply_guardrails_fn=apply_guardrails_fn,
            normalize_command_intent_fn=normalize_fn,
        )

    assert out.source == "legacy"
    assert seen["conversation_history"] is None
    assert seen["guardrails"] == 1
    assert seen["normalize"] == 1
    print("test_pipeline_legacy_fallback_without_history passed")


def test_pipeline_legacy_reuses_agent_facts_for_existing_task():
    day_tasks = [
        Task(
            id="task-run-1",
            title="跑步",
            start_time="2026-03-09T02:00:00+00:00",
            end_time="2026-03-09T02:30:00+00:00",
            priority="normal",
            status="pending",
            is_fixed=False,
        )
    ]

    def run_agent_fn(*_args, **_kwargs):
        return None

    def run_plan_critic_fn(**_kwargs):
        return None

    def resolve_graph_intent_fn(*_args, **_kwargs):
        return CommandIntent(intent="query", reply_text="unused")

    def parse_user_command_fn(*_args, **_kwargs):
        return CommandIntent(
            intent="insert",
            actions=[{"action": "insert", "title": "跑步"}],
            reply_text="legacy",
            parse_source="llm",
        )

    def apply_guardrails_fn(cmd, *_args, **_kwargs):
        return cmd

    def normalize_fn(cmd, *_args, **_kwargs):
        return cmd

    def get_agent_meta_fn():
        return {
            "protocol_failed": True,
            "tool_facts": {
                "tasks_by_title": {
                    "跑步": [{"id": "task-run-1", "title": "跑步"}]
                }
            },
        }

    with patch("service.command_pipeline.AGENT_ONLY_WRITE_MODE", False):
        out = run_command_pipeline(
            user_text="跑步前找朋友",
            today=date(2026, 3, 9),
            now_dt=datetime(2026, 3, 9, 10, 0, 0),
            day_tasks_for_ai=day_tasks,
            conversation_history=None,
            use_agent_mode=True,
            plan_critic_enabled=True,
            run_agent_fn=run_agent_fn,
            run_plan_critic_fn=run_plan_critic_fn,
            resolve_graph_intent_fn=resolve_graph_intent_fn,
            parse_user_command_fn=parse_user_command_fn,
            apply_guardrails_fn=apply_guardrails_fn,
            normalize_command_intent_fn=normalize_fn,
            get_agent_meta_fn=get_agent_meta_fn,
        )

    assert out.source == "legacy"
    assert isinstance(out.cmd.actions, list) and out.cmd.actions
    assert out.cmd.actions[0]["action"] == "plan"
    assert out.cmd.actions[0]["target_task_id"] == "task-run-1"
    print("test_pipeline_legacy_reuses_agent_facts_for_existing_task passed")


def test_pipeline_agent_only_write_mode_blocks_legacy_parse_path():
    calls = {"parse": 0}

    def run_agent_fn(*_args, **_kwargs):
        return None

    def run_plan_critic_fn(**_kwargs):
        return None

    def resolve_graph_intent_fn(*_args, **_kwargs):
        return CommandIntent(intent="query", reply_text="unused")

    def parse_user_command_fn(*_args, **_kwargs):
        calls["parse"] += 1
        return CommandIntent(intent="insert", actions=[{"action": "insert", "title": "跑步"}])

    def apply_guardrails_fn(cmd, *_args, **_kwargs):
        return cmd

    def normalize_fn(cmd, *_args, **_kwargs):
        return cmd

    with patch("service.command_pipeline.AGENT_ONLY_WRITE_MODE", True):
        out = run_command_pipeline(
            user_text="新增跑步",
            today=date(2026, 3, 9),
            now_dt=datetime(2026, 3, 9, 10, 0, 0),
            day_tasks_for_ai=[],
            conversation_history=None,
            use_agent_mode=True,
            plan_critic_enabled=True,
            run_agent_fn=run_agent_fn,
            run_plan_critic_fn=run_plan_critic_fn,
            resolve_graph_intent_fn=resolve_graph_intent_fn,
            parse_user_command_fn=parse_user_command_fn,
            apply_guardrails_fn=apply_guardrails_fn,
            normalize_command_intent_fn=normalize_fn,
        )

    assert out.source == "legacy"
    assert calls["parse"] == 0
    assert out.cmd.intent == "query"
    assert out.cmd.need_clarification is True
    assert "停止写入" in (out.cmd.reply_text or "")
    print("test_pipeline_agent_only_write_mode_blocks_legacy_parse_path passed")


if __name__ == "__main__":
    test_pipeline_agent_path_and_unified_normalize()
    test_pipeline_legacy_fallback_without_history()
    test_pipeline_legacy_reuses_agent_facts_for_existing_task()
    test_pipeline_agent_only_write_mode_blocks_legacy_parse_path()
    print("ALL command pipeline tests passed")
