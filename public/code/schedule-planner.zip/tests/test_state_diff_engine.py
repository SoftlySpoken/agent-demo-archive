import sys
import os
import types

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Optional deps stubs
if 'dateparser' not in sys.modules:
    _dp = types.ModuleType('dateparser')
    _dp.parse = lambda *args, **kwargs: None
    sys.modules['dateparser'] = _dp

if 'fuzzywuzzy' not in sys.modules:
    _fz = types.ModuleType('fuzzywuzzy')

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules['fuzzywuzzy'] = _fz

from db.models import Task
from logic.state_diff import compute_state_diff


def test_diff_update_and_insert():
    current = [
        Task(
            id='task-1',
            title='组会',
            start_time='2026-03-08T10:00:00+00:00',
            end_time='2026-03-08T11:00:00+00:00',
            priority='normal',
            status='pending',
            is_fixed=False,
        )
    ]
    desired = [
        {
            'id': 'task-1',
            'title': '组会',
            'start_iso': '2026-03-08T11:00:00',
            'end_iso': '2026-03-08T12:00:00',
        },
        {
            'title': '跑步',
            'start_iso': '2026-03-08T12:30:00',
            'end_iso': '2026-03-08T13:00:00',
            'priority': 'high',
        },
    ]

    actions = compute_state_diff(current, desired)
    assert len(actions) == 2
    assert actions[0]['action'] == 'update'
    assert actions[0]['target_task_id'] == 'task-1'
    assert actions[1]['action'] == 'insert'
    assert actions[1]['title'] == '跑步'
    print('test_diff_update_and_insert passed')


def test_diff_idempotent_no_change():
    current = [
        Task(
            id='task-1',
            title='组会',
            start_time='2026-03-08T10:00:00+00:00',
            end_time='2026-03-08T11:00:00+00:00',
            priority='normal',
            status='pending',
            is_fixed=False,
        )
    ]
    desired = [
        {
            'id': 'task-1',
            'title': '组会',
            'start_iso': '2026-03-08T10:00:00',
            'end_iso': '2026-03-08T11:00:00',
            'priority': 'normal',
            'status': 'pending',
            'is_fixed': False,
        }
    ]

    actions = compute_state_diff(current, desired)
    assert actions == []
    print('test_diff_idempotent_no_change passed')


def test_diff_unique_title_without_time_reuses_existing_task():
    current = [
        Task(
            id='task-run-1',
            title='跑步',
            start_time='2026-03-09T12:00:00+00:00',
            end_time='2026-03-09T13:00:00+00:00',
            priority='normal',
            status='pending',
            is_fixed=False,
            memo=None,
        )
    ]
    desired = [
        {
            'title': '跑步',
            'status': 'pending',
            'memo': '保持习惯',
        }
    ]

    actions = compute_state_diff(current, desired)
    assert len(actions) == 1
    assert actions[0]['action'] == 'update'
    assert actions[0]['target_task_id'] == 'task-run-1'
    assert actions[0]['memo'] == '保持习惯'
    print('test_diff_unique_title_without_time_reuses_existing_task passed')


def test_diff_ambiguous_title_without_time_falls_back_to_insert():
    current = [
        Task(
            id='task-run-1',
            title='跑步',
            start_time='2026-03-09T12:00:00+00:00',
            end_time='2026-03-09T13:00:00+00:00',
            priority='normal',
            status='pending',
            is_fixed=False,
            memo=None,
        ),
        Task(
            id='task-run-2',
            title='跑步',
            start_time='2026-03-09T15:00:00+00:00',
            end_time='2026-03-09T16:00:00+00:00',
            priority='normal',
            status='pending',
            is_fixed=False,
            memo=None,
        ),
    ]
    desired = [{'title': '跑步'}]

    actions = compute_state_diff(current, desired)
    assert len(actions) == 1
    assert actions[0]['action'] == 'insert'
    assert actions[0]['title'] == '跑步'
    print('test_diff_ambiguous_title_without_time_falls_back_to_insert passed')


if __name__ == '__main__':
    test_diff_update_and_insert()
    test_diff_idempotent_no_change()
    test_diff_unique_title_without_time_reuses_existing_task()
    test_diff_ambiguous_title_without_time_falls_back_to_insert()
    print('ALL state_diff tests passed')
