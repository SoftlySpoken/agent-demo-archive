
import sys
import os
import types
from unittest.mock import MagicMock, patch

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Optional deps stubs
if 'dateparser' not in sys.modules:
    _dp = types.ModuleType('dateparser')
    _dp.parse = lambda *args, **kwargs: None
    sys.modules['dateparser'] = _dp

if 'fuzzywuzzy' not in sys.modules:
    _fz = types.ModuleType('fuzzywuzzy')

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules['fuzzywuzzy'] = _fz

from service.app_service import handle_user_command, PendingPlan
from ai.models import CommandIntent
from db.models import Task

def test_replan_all_legacy_preview():
    """测试 Legacy 模式下（空 actions）的 replan_all 是否能产生预览。"""
    
    # 模拟 repository 任务
    mock_task = Task(
        id='test-uuid-1',
        title='测试任务',
        start_time='2026-03-07T10:00:00+00:00',
        end_time='2026-03-07T11:00:00+00:00',
        status='pending',
        is_fixed=False,
        priority='normal'
    )
    
    mock_repo = MagicMock()
    mock_task_2 = Task(
        id='test-uuid-2',
        title='测试任务2',
        start_time='2026-03-07T11:00:00+00:00',
        end_time='2026-03-07T12:00:00+00:00',
        status='pending',
        is_fixed=False,
        priority='normal'
    )
    mock_repo.tasks_for_date.return_value = [mock_task, mock_task_2]
    
    # 模拟 parse_user_command 返回 replan_all (Legacy 模式)
    mock_cmd = CommandIntent(
        intent='replan_all',
        actions=[],
        reply_text='[LEGACY] 重新规划所有任务'
    )
    
    with patch('config.USE_AGENT_MODE', False), \
         patch('service.app_service.repo', mock_repo), \
         patch('service.app_service.parse_user_command', return_value=mock_cmd), \
         patch('service.app_service.apply_guardrails', side_effect=lambda c, *_a, **_k: c), \
         patch('service.app_service.run_domino') as mock_domino:
        
        # 模拟 domino 结果（假设顺延了）
        mock_updated_1 = Task(
            id='test-uuid-1',
            title='测试任务',
            start_time='2026-03-07T11:00:00+00:00',
            end_time='2026-03-07T12:00:00+00:00',
            priority='normal',
            status='pending',
            is_fixed=False,
        )
        mock_updated_2 = Task(
            id='test-uuid-2',
            title='测试任务2',
            start_time='2026-03-07T12:00:00+00:00',
            end_time='2026-03-07T13:00:00+00:00',
            priority='normal',
            status='pending',
            is_fixed=False,
        )
        from logic.scheduler import DominoResult
        mock_domino.return_value = DominoResult(updated_tasks=[mock_updated_1, mock_updated_2], overflow_warning=None)
        
        reply, warn, plan, reasoning = handle_user_command("重新规划")
        
        print(f"--- Reply: {reply}")
        print(f"--- Plan Object: {plan}")
        
        assert plan is not None, "Legacy replan_all should return a PendingPlan object"
        assert len(plan.updates) == 2
        assert plan.updates[0]['title'] == '测试任务'
        print("✅ Legacy replan_all preview test passed!")

if __name__ == "__main__":
    try:
        test_replan_all_legacy_preview()
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
