import sys
import os
import types
from datetime import datetime
from unittest.mock import patch, MagicMock

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Test env stubs for optional deps
if 'dateparser' not in sys.modules:
    _dp = types.ModuleType('dateparser')
    _dp.parse = lambda *args, **kwargs: None
    sys.modules['dateparser'] = _dp

if 'fuzzywuzzy' not in sys.modules:
    _fz = types.ModuleType('fuzzywuzzy')
    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0
    _fz.fuzz = _Fuzz()
    sys.modules['fuzzywuzzy'] = _fz

from ai.models import CommandIntent
from db.models import Task
from service.app_service import handle_user_command


def test_desired_state_overrides_actions():
    cmd = CommandIntent(
        intent='plan',
        desired_state=[
            {
                'title': '新任务',
                'start_iso': '2026-03-08T10:00:00',
                'end_iso': '2026-03-08T11:00:00',
            }
        ],
        actions=[{'action': 'delete', 'target_task_id': 'should-not-run'}],
        reply_text='已根据目标态规划',
        planning_reason='测试目标态优先',
    )

    created = Task(
        id='new-task-id',
        title='新任务',
        start_time='2026-03-08T10:00:00+00:00',
        end_time='2026-03-08T11:00:00+00:00',
        priority='normal',
        status='pending',
        is_fixed=False,
    )

    with patch('config.USE_AGENT_MODE', False), \
         patch('service.app_service.parse_user_command', return_value=cmd), \
         patch('service.app_service.apply_guardrails', side_effect=lambda c, *_args, **_kwargs: c), \
         patch('service.app_service._prevalidate_actions', return_value=(True, '', 0)), \
         patch('service.app_service._verify_single_action_step_effect', return_value=(True, '')), \
         patch('service.app_service._reconcile_desired_state', return_value=(True, '', 0)), \
         patch('service.app_service.IDEMPOTENCY_FINGERPRINT_ENABLED', False), \
         patch('service.app_service.repo') as mock_repo:

        mock_repo.tasks_for_date.return_value = []
        mock_repo.save_snapshot.return_value = None
        mock_repo.insert_task.return_value = created
        mock_repo.delete_task = MagicMock()

        reply, warn, plan, reasoning = handle_user_command('帮我按目标态规划')

    # plan 意图采用“先预览后确认”模式：本轮仅返回待确认方案，不应提前写库
    assert '预览' in reply
    assert plan is not None
    assert isinstance(plan.actions, list) and len(plan.actions) >= 1
    assert not mock_repo.insert_task.called
    assert not mock_repo.delete_task.called
    print('test_desired_state_overrides_actions passed')


def test_desired_state_no_change_returns_noop():
    cmd = CommandIntent(
        intent='plan',
        desired_state=[
            {
                'id': 'task-1',
                'title': '组会',
                'start_iso': '2026-03-08T10:00:00',
                'end_iso': '2026-03-08T11:00:00',
            }
        ],
        reply_text='目标态已满足',
    )

    current = Task(
        id='task-1',
        title='组会',
        start_time='2026-03-08T10:00:00+00:00',
        end_time='2026-03-08T11:00:00+00:00',
        priority='normal',
        status='pending',
        is_fixed=False,
    )

    with patch('config.USE_AGENT_MODE', False), \
         patch('service.app_service.parse_user_command', return_value=cmd), \
         patch('service.app_service.apply_guardrails', side_effect=lambda c, *_args, **_kwargs: c), \
         patch('service.app_service.repo') as mock_repo:

        mock_repo.tasks_for_date.return_value = [current]
        mock_repo.save_snapshot.return_value = None
        mock_repo.insert_task = MagicMock()
        mock_repo.update_task = MagicMock()
        mock_repo.delete_task = MagicMock()

        reply, warn, plan, reasoning = handle_user_command('检查目标态')

    assert reply == '目标态已满足'
    assert plan is None
    assert not mock_repo.insert_task.called
    assert not mock_repo.update_task.called
    assert not mock_repo.delete_task.called
    print('test_desired_state_no_change_returns_noop passed')


if __name__ == '__main__':
    test_desired_state_overrides_actions()
    test_desired_state_no_change_returns_noop()
    print('ALL desired_state flow tests passed')
