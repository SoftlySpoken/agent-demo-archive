import json
from datetime import date
from unittest.mock import patch

from ai import tools
from db.models import Task


def _task(start_time: str, end_time: str) -> Task:
    return Task(
        id="t1",
        title="晚间跑步",
        start_time=start_time,
        end_time=end_time,
        priority="normal",
        status="pending",
        is_fixed=False,
    )


def test_check_conflict_handles_utc_and_local_naive_equivalence():
    # 12:00+00:00 == 本地 20:00（UTC+8）
    tasks = [_task("2026-03-09T12:00:00+00:00", "2026-03-09T13:00:00+00:00")]
    with patch.object(tools.repo, "tasks_for_date", return_value=tasks):
        raw = tools.check_conflict(
            date_str=date(2026, 3, 9).isoformat(),
            start_time="2026-03-09T20:00:00",
            end_time="2026-03-09T20:30:00",
        )
    data = json.loads(raw)
    assert data["has_conflict"] is True
    assert len(data["conflicting_tasks"]) == 1


def test_get_free_slots_skips_conflicting_task_under_mixed_time_formats():
    tasks = [_task("2026-03-09T12:00:00+00:00", "2026-03-09T13:00:00+00:00")]
    with patch.object(tools.repo, "tasks_for_date", return_value=tasks), patch.object(
        tools, "date"
    ) as mock_date:
        mock_date.fromisoformat.side_effect = date.fromisoformat
        mock_date.today.return_value = date(2026, 3, 9)
        raw = tools.get_free_slots(date_str="2026-03-09", duration_minutes=30)
    data = json.loads(raw)
    assert isinstance(data, list)
    assert len(data) >= 1
