import os
import sys
import types
from datetime import date, datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

if "dateparser" not in sys.modules:
    _dp = types.ModuleType("dateparser")
    _dp.parse = lambda *args, **kwargs: None
    sys.modules["dateparser"] = _dp

if "fuzzywuzzy" not in sys.modules:
    _fz = types.ModuleType("fuzzywuzzy")

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules["fuzzywuzzy"] = _fz

from db.models import Task
from service.app_service import _compile_actions_for_execution, _parse_local_naive


def _mk_task(tid: str, day: str, st: str, et: str, title: str) -> Task:
    return Task(
        id=tid,
        title=title,
        start_time=f"{day}T{st}+00:00",
        end_time=f"{day}T{et}+00:00",
        priority="normal",
        status="pending",
        is_fixed=False,
    )


def test_compile_insert_slot_when_explicit_time_conflicts():
    today = date(2026, 3, 9)
    day = today.isoformat()
    tasks = [
        _mk_task("dinner-1", day, "10:00:00", "11:00:00", "晚餐"),  # 18:00-19:00 local
    ]
    actions = [
        {
            "action": "insert",
            "title": "买菜",
            "duration_minutes": 30,
            "start_iso": f"{day}T18:00:00",
            "end_iso": f"{day}T18:30:00",
        }
    ]

    compiled, repaired = _compile_actions_for_execution(
        actions=actions,
        today=today,
        day_tasks=tasks,
        now_dt=datetime(2026, 3, 9, 9, 0, 0),
    )

    assert repaired >= 1
    out = compiled[0]
    st_local = _parse_local_naive(out["start_iso"])
    et_local = _parse_local_naive(out["end_iso"])
    assert st_local is not None and et_local is not None
    assert st_local.hour == 19 and st_local.minute == 0
    assert et_local.hour == 19 and et_local.minute == 30


def test_compile_propagates_parent_shift_to_dependent_update():
    today = date(2026, 3, 9)
    day = today.isoformat()
    tasks = [
        _mk_task("dinner-1", day, "10:00:00", "11:00:00", "晚餐"),  # 18:00-19:00 local
        _mk_task("paper-1", day, "11:00:00", "12:00:00", "读论文"),   # 19:00-20:00 local
    ]
    actions = [
        {
            "action": "insert",
            "source_node_id": "node_1",
            "title": "买菜",
            "duration_minutes": 30,
            "start_iso": f"{day}T18:00:00",
            "end_iso": f"{day}T18:30:00",
        },
        {
            "action": "update",
            "source_node_id": "node_2",
            "target_task_id": "paper-1",
            "resolved_parent_id": "node_1",
            "new_start_iso": f"{day}T18:30:00",
            "new_end_iso": f"{day}T19:30:00",
        },
    ]

    compiled, repaired = _compile_actions_for_execution(
        actions=actions,
        today=today,
        day_tasks=tasks,
        now_dt=datetime(2026, 3, 9, 9, 0, 0),
    )

    assert repaired >= 2
    insert_act, update_act = compiled
    insert_end_local = _parse_local_naive(insert_act["end_iso"])
    update_start_local = _parse_local_naive(update_act["new_start_iso"])
    assert insert_end_local is not None and update_start_local is not None
    assert update_start_local >= insert_end_local
    assert update_start_local.hour == 19 and update_start_local.minute == 30


def test_compile_update_avoids_overlap_with_existing_task():
    today = date(2026, 3, 9)
    day = today.isoformat()
    tasks = [
        _mk_task("vitd-1", day, "10:55:00", "11:00:00", "吃维生素D"),  # 18:55-19:00 local
        _mk_task("grocery-1", day, "11:00:00", "11:30:00", "买菜"),      # 19:00-19:30 local
    ]
    actions = [
        {
            "action": "update",
            "target_task_id": "vitd-1",
            "new_start_iso": f"{day}T19:00:00",
            "new_end_iso": f"{day}T19:05:00",
        }
    ]

    compiled, repaired = _compile_actions_for_execution(
        actions=actions,
        today=today,
        day_tasks=tasks,
        now_dt=datetime(2026, 3, 9, 9, 0, 0),
    )

    assert repaired >= 1
    out = compiled[0]
    st_local = _parse_local_naive(out["new_start_iso"])
    et_local = _parse_local_naive(out["new_end_iso"])
    assert st_local is not None and et_local is not None
    assert st_local.hour == 19 and st_local.minute == 30
    assert et_local.hour == 19 and et_local.minute == 35
