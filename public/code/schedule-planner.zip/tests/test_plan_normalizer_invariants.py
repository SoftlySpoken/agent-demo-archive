import os
import sys
import types
from datetime import date

# Add project root
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Optional deps stubs
if "dateparser" not in sys.modules:
    _dp = types.ModuleType("dateparser")
    _dp.parse = lambda *args, **kwargs: None
    sys.modules["dateparser"] = _dp

if "fuzzywuzzy" not in sys.modules:
    _fz = types.ModuleType("fuzzywuzzy")

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules["fuzzywuzzy"] = _fz

from ai.models import CommandIntent
from db.models import Task
from logic.plan_normalizer import normalize_command_intent
from service.app_service import _extract_action_date, _local_iso_to_utc_iso


def test_normalizer_builds_expected_delta_for_insert():
    cmd = CommandIntent(
        intent="plan",
        actions=[
            {
                "action": "insert",
                "target_title_expr": "找朋友",
                "new_start_iso": "2026-03-09T09:00:00",
                "new_end_iso": "2026-03-09T10:00:00",
                "new_duration_minutes": 60,
            }
        ],
    )
    out = normalize_command_intent(cmd, date(2026, 3, 9), day_tasks=[])
    assert isinstance(out.actions, list) and len(out.actions) == 1
    act = out.actions[0]
    assert act["title"] == "找朋友"
    assert act["duration_minutes"] == 60
    assert isinstance(act.get("expected_delta"), dict)
    assert act["expected_delta"].get("title") == "找朋友"
    assert act["expected_delta"].get("start_iso") == "2026-03-09T09:00:00"
    print("test_normalizer_builds_expected_delta_for_insert passed")


def test_normalizer_resolves_target_task_id_for_update():
    existing = Task(
        id="task-123",
        start_time="2026-03-09T01:00:00+00:00",
        end_time="2026-03-09T02:00:00+00:00",
        title="组会",
        priority="normal",
        status="pending",
        is_fixed=False,
    )
    cmd = CommandIntent(
        intent="plan",
        actions=[
            {
                "action": "update",
                "target_title_expr": "组会",
                "start_iso": "2026-03-09T10:30:00",
                "end_iso": "2026-03-09T11:30:00",
            }
        ],
    )
    out = normalize_command_intent(cmd, date(2026, 3, 9), day_tasks=[existing])
    act = out.actions[0]
    assert act.get("target_task_id") == "task-123"
    assert act.get("new_start_iso") == "2026-03-09T10:30:00"
    assert act.get("new_end_iso") == "2026-03-09T11:30:00"
    assert act.get("expected_delta", {}).get("target_task_id") == "task-123"
    print("test_normalizer_resolves_target_task_id_for_update passed")


def test_extract_action_date_uses_local_day_semantics():
    local_day = date(2026, 3, 9)
    local_expr = "2026-03-09T02:00:00"
    utc_iso = _local_iso_to_utc_iso(local_expr)
    extracted = _extract_action_date({"start_iso": utc_iso}, local_day)
    assert extracted == local_day.isoformat()
    print("test_extract_action_date_uses_local_day_semantics passed")


def test_normalizer_adds_canonical_id_and_dedup():
    cmd = CommandIntent(
        intent="plan",
        actions=[
            {
                "action": "insert",
                "title": "跑步",
                "start_iso": "2026-03-09T09:00:00",
                "end_iso": "2026-03-09T10:00:00",
            },
            {
                "action": "insert",
                "title": "跑步",
                "start_iso": "2026-03-09T09:00:00",
                "end_iso": "2026-03-09T10:00:00",
            },
        ],
    )
    out = normalize_command_intent(cmd, date(2026, 3, 9), day_tasks=[])
    assert isinstance(out.actions, list)
    assert len(out.actions) == 1
    act = out.actions[0]
    assert isinstance(act.get("_canonical_id"), str) and len(act.get("_canonical_id")) == 16
    assert act.get("_canonical_intent") == "plan"
    print("test_normalizer_adds_canonical_id_and_dedup passed")


if __name__ == "__main__":
    test_normalizer_builds_expected_delta_for_insert()
    test_normalizer_resolves_target_task_id_for_update()
    test_extract_action_date_uses_local_day_semantics()
    test_normalizer_adds_canonical_id_and_dedup()
    print("ALL plan normalizer invariants tests passed")
