import sys
import os
import types
from datetime import date
from unittest.mock import patch, call

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Optional deps stubs
if 'dateparser' not in sys.modules:
    _dp = types.ModuleType('dateparser')
    _dp.parse = lambda *args, **kwargs: None
    sys.modules['dateparser'] = _dp

if 'fuzzywuzzy' not in sys.modules:
    _fz = types.ModuleType('fuzzywuzzy')

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules['fuzzywuzzy'] = _fz

from db.models import Task
from service.app_service import (
    _restore_tasks_from_snapshot,
    _restore_tasks_from_scope_snapshot,
    _tasks_for_action_scope,
    _extract_desired_date,
)


def _mk_task(tid: str, start_iso: str, end_iso: str, title: str = "任务"):
    return Task(
        id=tid,
        title=title,
        start_time=start_iso,
        end_time=end_iso,
        priority='normal',
        status='pending',
        is_fixed=False,
    )


def test_restore_snapshot_removes_new_tasks_not_in_snapshot():
    today = date(2026, 3, 9)
    snapshot_payload = [
        {
            "id": "task-1",
            "start_time": "2026-03-09T00:00:00+00:00",
            "end_time": "2026-03-09T01:00:00+00:00",
            "priority": "normal",
            "status": "pending",
            "is_fixed": False,
            "memo": None,
        }
    ]
    current_tasks = [
        _mk_task("task-1", "2026-03-09T00:00:00+00:00", "2026-03-09T01:00:00+00:00"),
        _mk_task("task-new", "2026-03-09T02:00:00+00:00", "2026-03-09T03:00:00+00:00"),
    ]

    with patch('service.app_service.repo.tasks_for_date', return_value=current_tasks), \
         patch('service.app_service.repo.delete_task') as mock_delete, \
         patch('service.app_service.repo.update_task') as mock_update:
        restored = _restore_tasks_from_snapshot(snapshot_payload, today)

    assert restored == 1
    mock_delete.assert_called_once_with("task-new")
    mock_update.assert_called_once()
    assert mock_update.call_args[0][0] == "task-1"
    print('test_restore_snapshot_removes_new_tasks_not_in_snapshot passed')


def test_tasks_for_action_scope_fetches_fallback_and_action_date():
    fallback_day = date(2026, 3, 9)
    action = {
        "action": "insert",
        "title": "跨日任务",
        "start_iso": "2026-03-10T10:00:00",
        "end_iso": "2026-03-10T11:00:00",
    }
    day_9_tasks = [_mk_task("d9", "2026-03-09T01:00:00+00:00", "2026-03-09T02:00:00+00:00")]
    day_10_tasks = [_mk_task("d10", "2026-03-10T01:00:00+00:00", "2026-03-10T02:00:00+00:00")]

    with patch('service.app_service.repo.tasks_for_date', side_effect=[day_9_tasks, day_10_tasks]) as mock_fetch:
        tasks = _tasks_for_action_scope(action, fallback_day)

    assert len(tasks) == 2
    assert {t.id for t in tasks} == {"d9", "d10"}
    assert mock_fetch.call_args_list == [call(date(2026, 3, 9)), call(date(2026, 3, 10))]
    print('test_tasks_for_action_scope_fetches_fallback_and_action_date passed')


def test_tasks_for_action_scope_naive_local_time_keeps_same_day():
    fallback_day = date(2026, 3, 9)
    action = {
        "action": "insert",
        "title": "吃维生素D",
        "start_iso": "2026-03-09T18:50:00",
        "end_iso": "2026-03-09T19:00:00",
    }
    day_9_tasks = [_mk_task("d9", "2026-03-09T10:00:00+00:00", "2026-03-09T11:00:00+00:00")]

    with patch('service.app_service.repo.tasks_for_date', return_value=day_9_tasks) as mock_fetch:
        tasks = _tasks_for_action_scope(action, fallback_day)

    assert len(tasks) == 1
    assert {t.id for t in tasks} == {"d9"}
    assert mock_fetch.call_args_list == [call(date(2026, 3, 9))]
    print('test_tasks_for_action_scope_naive_local_time_keeps_same_day passed')


def test_extract_desired_date_naive_local_time_not_shift_to_next_day():
    fallback_day = date(2026, 3, 9)
    item = {
        "title": "吃维生素D",
        "start_iso": "2026-03-09T18:50:00",
        "end_iso": "2026-03-09T19:00:00",
    }
    got = _extract_desired_date(item, fallback_day)
    assert got == "2026-03-09"
    print('test_extract_desired_date_naive_local_time_not_shift_to_next_day passed')


def test_restore_scope_snapshot_across_two_days():
    scope_days = [date(2026, 3, 9), date(2026, 3, 10)]
    snapshot_payload = [
        {
            "id": "task-1",
            "start_time": "2026-03-09T00:00:00+00:00",
            "end_time": "2026-03-09T01:00:00+00:00",
            "priority": "normal",
            "status": "pending",
            "is_fixed": False,
            "memo": None,
        },
        {
            "id": "task-2",
            "start_time": "2026-03-10T00:00:00+00:00",
            "end_time": "2026-03-10T01:00:00+00:00",
            "priority": "normal",
            "status": "pending",
            "is_fixed": False,
            "memo": None,
        },
    ]
    day_9_tasks = [
        _mk_task("task-1", "2026-03-09T00:00:00+00:00", "2026-03-09T01:00:00+00:00"),
        _mk_task("task-new-9", "2026-03-09T02:00:00+00:00", "2026-03-09T03:00:00+00:00"),
    ]
    day_10_tasks = [
        _mk_task("task-2", "2026-03-10T00:00:00+00:00", "2026-03-10T01:00:00+00:00"),
        _mk_task("task-new-10", "2026-03-10T02:00:00+00:00", "2026-03-10T03:00:00+00:00"),
    ]

    with patch('service.app_service.repo.tasks_for_date', side_effect=[day_9_tasks, day_10_tasks]), \
         patch('service.app_service.repo.delete_task') as mock_delete, \
         patch('service.app_service.repo.update_task') as mock_update:
        restored = _restore_tasks_from_scope_snapshot(snapshot_payload, scope_days)

    assert restored == 2
    assert mock_delete.call_count == 2
    deleted_ids = {c.args[0] for c in mock_delete.call_args_list}
    assert deleted_ids == {"task-new-9", "task-new-10"}
    assert mock_update.call_count == 2
    print('test_restore_scope_snapshot_across_two_days passed')


if __name__ == '__main__':
    test_restore_snapshot_removes_new_tasks_not_in_snapshot()
    test_tasks_for_action_scope_fetches_fallback_and_action_date()
    test_tasks_for_action_scope_naive_local_time_keeps_same_day()
    test_extract_desired_date_naive_local_time_not_shift_to_next_day()
    test_restore_scope_snapshot_across_two_days()
    print('ALL reconcile scope & rollback tests passed')
