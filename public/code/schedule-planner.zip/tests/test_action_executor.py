import os
import sys
import types
from datetime import date

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Optional deps stubs
if "dateparser" not in sys.modules:
    _dp = types.ModuleType("dateparser")
    _dp.parse = lambda *args, **kwargs: None
    sys.modules["dateparser"] = _dp

if "fuzzywuzzy" not in sys.modules:
    _fz = types.ModuleType("fuzzywuzzy")

    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0

    _fz.fuzz = _Fuzz()
    sys.modules["fuzzywuzzy"] = _fz

from db.models import Task
from service.action_executor import ActionExecutor


def _mk_task(tid: str):
    return Task(
        id=tid,
        title="任务",
        start_time="2026-03-09T00:00:00+00:00",
        end_time="2026-03-09T01:00:00+00:00",
        priority="normal",
        status="pending",
        is_fixed=False,
    )


def test_action_executor_runs_default_validate_and_verify():
    called = {"apply": 0, "validate": 0, "verify": 0}
    today = date(2026, 3, 9)
    before = [_mk_task("task-1")]
    after = [_mk_task("task-1")]
    after[0].memo = "x"

    def fetch_scope(_action, _today):
        return before if called["apply"] == 0 else after

    def validate(_action, _today, _before):
        called["validate"] += 1
        return True, ""

    def apply_write():
        called["apply"] += 1

    def verify(_action, _before, _after, _today):
        called["verify"] += 1
        return True, "", _after

    executor = ActionExecutor(
        today=today,
        fetch_scope_tasks_fn=fetch_scope,
        verify_with_repair_fn=verify,
        default_validate_step_fn=validate,
    )
    res = executor.execute({"action": "update", "target_task_id": "task-1"}, apply_write_fn=apply_write, step_index=1)
    assert res.ok is True
    assert called["validate"] == 1
    assert called["apply"] == 1
    assert called["verify"] == 1
    print("test_action_executor_runs_default_validate_and_verify passed")


def test_action_executor_calls_rollback_on_verify_fail():
    called = {"apply": 0, "rollback": 0}
    today = date(2026, 3, 9)
    before = [_mk_task("task-1")]

    def fetch_scope(_action, _today):
        return before

    def validate(_action, _today, _before):
        return True, ""

    def apply_write():
        called["apply"] += 1

    def verify(_action, _before, _after, _today):
        return False, "verify failed", _after

    def rollback():
        called["rollback"] += 1
        return 1

    executor = ActionExecutor(
        today=today,
        fetch_scope_tasks_fn=fetch_scope,
        verify_with_repair_fn=verify,
        default_validate_step_fn=validate,
    )
    res = executor.execute(
        {"action": "update", "target_task_id": "task-1"},
        apply_write_fn=apply_write,
        step_index=1,
        rollback_fn=rollback,
    )
    assert res.ok is False
    assert called["apply"] == 1
    assert called["rollback"] == 1
    assert res.rolled_back_count == 1
    print("test_action_executor_calls_rollback_on_verify_fail passed")


if __name__ == "__main__":
    test_action_executor_runs_default_validate_and_verify()
    test_action_executor_calls_rollback_on_verify_fail()
    print("ALL action_executor tests passed")
