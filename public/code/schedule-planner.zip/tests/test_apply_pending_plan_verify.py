import sys
import os
import types
from datetime import date
from unittest.mock import patch

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Optional deps stubs
if 'dateparser' not in sys.modules:
    _dp = types.ModuleType('dateparser')
    _dp.parse = lambda *args, **kwargs: None
    sys.modules['dateparser'] = _dp

if 'fuzzywuzzy' not in sys.modules:
    _fz = types.ModuleType('fuzzywuzzy')
    class _Fuzz:
        @staticmethod
        def token_set_ratio(a, b):
            return 100 if str(a) == str(b) else 0
    _fz.fuzz = _Fuzz()
    sys.modules['fuzzywuzzy'] = _fz

from db.models import Task
from service.app_service import PendingPlan, apply_pending_plan, _WRITE_FINGERPRINT_CACHE


def _mk_task(tid: str, day: str, st: str, et: str, title: str):
    return Task(
        id=tid,
        title=title,
        start_time=f'{day}T{st}+00:00',
        end_time=f'{day}T{et}+00:00',
        priority='normal',
        status='pending',
        is_fixed=False,
    )


def test_apply_pending_plan_with_desired_state_mismatch_warning():
    _WRITE_FINGERPRINT_CACHE.clear()
    day = date.today().isoformat()
    before = _mk_task('task-1', day, '09:00:00', '10:00:00', '组会')
    after_wrong = _mk_task('task-1', day, '08:00:00', '09:00:00', '组会')

    plan = PendingPlan(
        user_text='测试',
        updates=[
            {
                'id': 'task-1',
                'new_start': f'{day}T08:00:00+00:00',
                'new_end': f'{day}T09:00:00+00:00',
            }
        ],
        desired_state=[
            {
                'id': 'task-1',
                'title': '组会',
                'start_iso': f'{day}T10:00:00',
                'end_iso': f'{day}T11:00:00',
            }
        ],
    )

    with patch('service.app_service.repo.tasks_for_date', side_effect=[[before], [before], [after_wrong], [after_wrong]]), \
         patch('service.app_service.repo.save_snapshot', return_value=None), \
         patch('service.app_service._verify_single_action_step_effect', return_value=(True, '')), \
         patch('service.app_service.repo.update_task', return_value=after_wrong), \
         patch('service.app_service._reconcile_desired_state', return_value=(False, '目标态校验发现 1 处偏差。', 0)), \
         patch('service.app_service._restore_tasks_from_scope_snapshot', return_value=1), \
         patch('service.app_service.IDEMPOTENCY_FINGERPRINT_ENABLED', False):
        msg, warn = apply_pending_plan(plan)

    assert '执行失败' in msg
    assert '回滚' in msg
    assert warn is not None and '目标态校验发现' in warn
    print('test_apply_pending_plan_with_desired_state_mismatch_warning passed')


def test_apply_pending_plan_with_desired_state_match_ok():
    _WRITE_FINGERPRINT_CACHE.clear()
    day = date.today().isoformat()
    before = _mk_task('task-1', day, '09:00:00', '10:00:00', '组会')
    after_ok = _mk_task('task-1', day, '10:00:00', '11:00:00', '组会')

    plan = PendingPlan(
        user_text='测试',
        updates=[
            {
                'id': 'task-1',
                'new_start': f'{day}T10:00:00+00:00',
                'new_end': f'{day}T11:00:00+00:00',
            }
        ],
        desired_state=[
            {
                'id': 'task-1',
                'title': '组会',
                'start_iso': f'{day}T10:00:00',
                'end_iso': f'{day}T11:00:00',
            }
        ],
    )

    with patch('service.app_service.repo.tasks_for_date', side_effect=[[before], [before], [after_ok], [after_ok]]), \
         patch('service.app_service.repo.save_snapshot', return_value=None), \
         patch('service.app_service._verify_single_action_step_effect', return_value=(True, '')), \
         patch('service.app_service.repo.update_task', return_value=after_ok), \
         patch('service.app_service._reconcile_desired_state', return_value=(True, '', 0)), \
         patch('service.app_service.IDEMPOTENCY_FINGERPRINT_ENABLED', False):
        msg, warn = apply_pending_plan(plan)

    assert msg == '已按预览结果执行调整。'
    assert warn is None
    print('test_apply_pending_plan_with_desired_state_match_ok passed')


def test_apply_pending_plan_with_autofix_success():
    _WRITE_FINGERPRINT_CACHE.clear()
    day = date.today().isoformat()
    before = _mk_task('task-1', day, '09:00:00', '10:00:00', '组会')
    after_wrong = _mk_task('task-1', day, '08:00:00', '09:00:00', '组会')

    plan = PendingPlan(
        user_text='测试',
        updates=[
            {
                'id': 'task-1',
                'new_start': f'{day}T08:00:00+00:00',
                'new_end': f'{day}T09:00:00+00:00',
            }
        ],
        desired_state=[
            {
                'id': 'task-1',
                'title': '组会',
                'start_iso': f'{day}T10:00:00',
                'end_iso': f'{day}T11:00:00',
            }
        ],
    )

    with patch('service.app_service.repo.tasks_for_date', return_value=[before]), \
         patch('service.app_service.repo.save_snapshot', return_value=None), \
         patch('service.app_service._verify_single_action_step_effect', return_value=(True, '')), \
         patch('service.app_service.repo.update_task', return_value=after_wrong), \
         patch('service.app_service._reconcile_desired_state', return_value=(True, '目标态已收敛（自动补救 1 处）。', 1)), \
         patch('service.app_service.DESIRED_STATE_AUTOFIX_ENABLED', True), \
         patch('service.app_service.DESIRED_STATE_AUTOFIX_MAX_ACTIONS', 2), \
         patch('service.app_service.DESIRED_STATE_AUTOFIX_ALLOW_INSERT', False), \
         patch('service.app_service.IDEMPOTENCY_FINGERPRINT_ENABLED', False):
        msg, warn = apply_pending_plan(plan)

    assert msg == '已按预览结果执行调整，并完成自动补救。'
    assert warn is not None and '目标态已收敛（自动补救 1 处）。' in warn
    print('test_apply_pending_plan_with_autofix_success passed')


def test_apply_pending_plan_duplicate_confirm_blocked():
    day = date.today().isoformat()
    before = _mk_task('task-1', day, '09:00:00', '10:00:00', '组会')
    after_ok = _mk_task('task-1', day, '10:00:00', '11:00:00', '组会')
    _WRITE_FINGERPRINT_CACHE.clear()

    plan = PendingPlan(
        user_text='测试',
        updates=[
            {
                'id': 'task-1',
                'new_start': f'{day}T10:00:00+00:00',
                'new_end': f'{day}T11:00:00+00:00',
            }
        ],
    )

    with patch('service.app_service.repo.tasks_for_date', return_value=[before]), \
         patch('service.app_service.repo.save_snapshot', return_value=None), \
         patch('service.app_service._verify_single_action_step_effect', return_value=(True, '')), \
         patch('service.app_service.repo.update_task', return_value=after_ok), \
         patch('service.app_service.IDEMPOTENCY_FINGERPRINT_ENABLED', True), \
         patch('service.app_service.IDEMPOTENCY_FINGERPRINT_TTL_SECONDS', 600), \
         patch('service.app_service._PERSISTENT_IDEM_STORE.is_recent', return_value=False):
        msg1, warn1 = apply_pending_plan(plan)
        msg2, warn2 = apply_pending_plan(plan)

    assert msg1 == '已按预览结果执行调整。'
    assert warn1 is None
    assert '重复确认请求' in msg2
    assert warn2 is None
    print('test_apply_pending_plan_duplicate_confirm_blocked passed')


def test_apply_pending_plan_state_version_mismatch_blocked():
    day = date.today().isoformat()
    _WRITE_FINGERPRINT_CACHE.clear()
    plan = PendingPlan(
        user_text='测试',
        updates=[
            {
                'id': 'task-1',
                'new_start': f'{day}T10:00:00+00:00',
                'new_end': f'{day}T11:00:00+00:00',
            }
        ],
        state_version='version-preview-old',
    )

    with patch('service.app_service._compute_scope_state_version', return_value='version-latest-new'):
        msg, warn = apply_pending_plan(plan)

    assert '日程已变化' in msg
    assert warn is None
    print('test_apply_pending_plan_state_version_mismatch_blocked passed')


if __name__ == '__main__':
    test_apply_pending_plan_with_desired_state_mismatch_warning()
    test_apply_pending_plan_with_desired_state_match_ok()
    test_apply_pending_plan_with_autofix_success()
    test_apply_pending_plan_duplicate_confirm_blocked()
    test_apply_pending_plan_state_version_mismatch_blocked()
    print('ALL apply_pending_plan verify tests passed')
