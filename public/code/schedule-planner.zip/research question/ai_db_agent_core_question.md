# AI DB Agent 核心研究问题（一页版）

## 最有价值的研究问题

**如何将自然语言数据意图编译为跨数据库环境、可验证、可回滚的事务型状态变更？**

英文表述：

**How can natural-language data intents be compiled into cross-database, verifiable, recoverable transactional state transitions?**

这句话比 `text-to-SQL` 或 `text2CRUD` 更适合作为 2026 年及以后的 AI DB Agent 主问题，因为它覆盖的不只是查询，还包括：

- `query`
- `update / insert / delete`
- `multi-step workflow`
- `transaction boundary`
- `post-condition verification`
- `rollback / repair`

---

## 这个问题为什么重要

### 1. 研究对象已经从“生成 SQL”变成“完成数据工作流”

[Spider 2.0](https://arxiv.org/abs/2411.07763) 明确指出，真实企业 text-to-SQL workflow 往往涉及复杂云/本地数据库、多 SQL dialect、数据转换与分析、多查询生成，以及对 metadata、文档甚至项目级代码库的理解。论文报告，基于 `o1-preview` 的 code agent 在 Spider 2.0 上只解决了 **21.3%** 任务，而在 Spider 1.0 和 BIRD 上分别达到 **91.2%** 和 **73.0%**。这说明“能生成 SQL”不等于“能完成真实数据库任务”。

这条趋势在 2025 年底也被进一步强化。[DySQL-Bench](https://arxiv.org/abs/2510.26495) 专门提出了 **dynamic multi-turn SQL interaction** 问题：用户会基于中间结果不断修改约束、维度和查询目标，模型必须在多轮交互中持续修正 SQL。该 benchmark 覆盖 **13** 个领域、共 **1,072** 个任务，并报告即使是 `GPT-4o` 总体准确率也只有 **58.34%**，`Pass@5` 只有 **23.81%**。这说明数据库 agent 的难点正在从静态单轮问答转向动态交互式探索。

### 2. 数据库系统本身正在转向 agent-first

[CIDR 2026 的 agent-first 数据系统论文](https://www.vldb.org/cidrdb/2026/supporting-our-ai-overlords-redesigning-data-systems-to-be-agent-first.html) 直接提出：LLM agents 很可能成为未来数据系统的主导 workload。论文把这种 workload 的核心特征概括为 `scale / heterogeneity / redundancy / steerability`，并认为数据库需要为 agentic workloads 重新设计 query interface、query processing 和 memory store。

### 3. 工业系统已经开始要求“安全写数据库”，而不是只读查询

[BridgeScope（CIDR 2026）](https://www.vldb.org/cidrdb/2026/bridgescope-a-universal-toolkit-for-bridging-large-language-models-and-databases.html) 明确把数据库 agent 的工具层拆成 context retrieval、CRUD 执行和 **ACID-compliant transaction management**，同时把 privilege 和 security policy 纳入工具设计。这说明真正的 AI DB agent 问题已经进入“安全修改数据库”的阶段。

---

## 和传统问题相比，真正的新挑战在哪里

传统问题通常是：

- `text-to-SQL`
- `semantic parsing`
- `text2CRUD`

它们的默认假设是：用户意图清晰、任务是单步的、执行成功主要看 SQL 是否能跑通。

但 AI DB Agent 的核心问题已经不同了。

### 挑战 1：从单步查询变成多步事务

传统 `text-to-SQL` 通常只需要输出一条查询；AI DB agent 则经常需要：

1. 探索 schema / metadata
2. 生成计划
3. 执行多步操作
4. 检查结果
5. 失败时补救或回滚

### 挑战 2：从“执行正确”变成“状态正确”

传统 benchmark 多数以 execution accuracy 为核心指标，但对写操作来说，这不够。真正重要的是：

- 最终状态是否满足用户意图
- 是否修改了不该修改的数据
- 如果中途失败，是否还能恢复

[CIDR 2026 的 query rewrite 验证论文](https://www.vldb.org/cidrdb/2026/leveraging-query-optimizers-to-verify-the-soundness-of-llm-based-query-rewrites-for-real-world-workloads.html) 也指出，即使 LLM-based rewriting 在真实 workload 上有前景，**无法保证语义等价** 仍然是落地的主要障碍。

### 挑战 3：从 SELECT-only 变成 full SQL spectrum

`text2CRUD` 虽然比 `text-to-SQL` 更进一步，但它仍然容易停留在“接口翻译”层面；而 AI DB agent 的难点在于：

- 多步写操作
- ACID 约束
- 权限控制
- 审计与可追责
- rollback / repair

因此，更准确的抽象不是 `text2CRUD`，而是：

**text -> transactional state transition**

### 挑战 4：从静态数据集变成动态、长上下文、交互式环境

真实数据库任务不只依赖表结构，还依赖：

- 外部知识
- 业务规则
- 长文档
- 多轮澄清
- 环境变化

这意味着 AI DB agent 既是 database problem，也是 agent systems problem。

---

## 现有 benchmark 能不能直接用

结论先说：

**可以部分直接用，但还没有一个公开 benchmark 完整覆盖“事务型状态变更 + rollback correctness”。**

### 1. 可以直接用的 benchmark

#### BIRD

[BIRD（NeurIPS 2023）](https://arxiv.org/abs/2305.03111) 适合做强 baseline。它包含 **12,751** 个 text-to-SQL 对、**95** 个数据库、总计 **33.4 GB** 数据，突出大规模数据库值、脏数据、外部知识和 SQL 效率问题。  
适用点：适合验证 schema grounding、value grounding、复杂查询生成。  
局限：核心仍然偏查询，不是事务执行 benchmark。

#### Spider 2.0

[Spider 2.0（ICLR 2025 Oral）](https://arxiv.org/abs/2411.07763) 是目前最直接相关的 benchmark 之一。它包含 **632** 个真实企业级 workflow 问题，要求模型处理复杂环境、长上下文、多查询、多 dialect 和 project-level artifacts。  
适用点：适合验证“数据库 agent 是否能完成真实工作流”。  
局限：仍然主要面向 enterprise text-to-SQL workflow，不是严格意义上的事务安全 benchmark。

#### DySQL-Bench

[DySQL-Bench（arXiv 2025）](https://arxiv.org/abs/2510.26495) 关注 **dynamic multi-turn SQL interaction**，通过用户意图动态变化来评估模型在真实数据库探索场景中的持续适应能力。它基于 BIRD 和 Spider 2 数据库构造了 **1,072** 个任务，并引入了 user-model-database 三方交互式评估框架。  
适用点：适合验证多轮澄清、约束修改、交互式数据库探索。  
局限：它很好地补上了“多轮动态查询”这一块，但核心仍然偏 query refinement，而不是事务写入、post-condition 验证或 rollback correctness。

#### Spider 2.0-DBT

[Spider 2.0 官网](https://spider2-sql.github.io/) 已明确把 `Spider 2.0-DBT` 定义为 **68 个 repository-level code agent tasks**。  
适用点：适合验证 DB agent 在代码库、dbt 模型和 SQL workflow 上的能力。  
局限：更接近 analytics engineering，而不是通用数据库事务控制。

#### LiveSQLBench

[LiveSQLBench](https://livesqlbench.ai/) 是 2025-2026 很值得关注的新 benchmark。它自称支持 **full SQL spectrum**，不仅有 SELECT，还覆盖 **CRUD**、BI 和 data manipulation，并提供 test cases。  
适用点：如果你的研究问题包含写操作，这是当前最接近的公开 benchmark。  
局限：它已经覆盖 CRUD，但仍不等于完整事务语义评测；公开标准还没有把 rollback correctness、跨事务一致性作为中心指标。

#### BIRD-Interact

[BIRD-Interact（ICLR 2026 Oral）](https://bird-interact.github.io/) 是交互式 DB agent benchmark，包含 user simulator、knowledge base、documentation、两种 interaction mode，以及 **600** 个带 executable test cases 的任务，且覆盖 **full CRUD operations**。  
适用点：适合验证“AI DB agent 在交互、澄清、环境探索中的表现”。  
局限：它把交互 realism 做得很好，但仍不是专门针对 ACID / rollback 的 benchmark。

### 2. 不能直接覆盖的部分

如果主问题是：

**自然语言 -> 可验证、可回滚的事务型状态变更**

那么现有公开 benchmark 还缺三块：

1. **事务边界正确性**
2. **失败后的 rollback 正确性**
3. **post-condition / final-state correctness**

也就是说，今天已经有适合评估 `query generation`、`interactive CRUD`、`DB workflow agent` 的 benchmark，但**还没有一个成熟公开 benchmark 专门把“事务型状态变更 correctness”作为中心对象**。这本身就是一个明确的 research gap。

---

## 最终判断

如果你想选一个**最值钱、最前沿、又不是空泛口号**的 AI DB Agent 研究问题，我建议就用这一句：

**如何将自然语言数据意图编译为跨数据库环境、可验证、可回滚的事务型状态变更？**

它的优势是：

- 比 `text-to-SQL` 更前沿
- 比 `text2CRUD` 更准确
- 能覆盖查询、写操作、事务、回滚、验证
- 与 2025-2026 的 benchmark、CIDR 论文和工业系统方向一致
- 同时留下明确研究空白：**benchmark 还不完整，特别是事务 correctness 仍缺标准化评测**

---

## 更现实的两步研究路径

如果从“现在就能做、并且最好能直接落在现有 benchmark 上”的角度看，确实不适合一步跳到完整的 `transactional state transition`。更稳妥的做法是分两步。

### 第一步：先做当前 benchmark 可直接承载的问题

更现实的当前研究问题可以写成：

**如何提升 AI DB agent 在动态多轮数据库交互中的正确性与稳定性？**

英文表述：

**How can we improve the correctness and robustness of AI DB agents under dynamic multi-turn database interaction?**

这个问题的好处是：

- 可以直接落在 [DySQL-Bench](https://arxiv.org/abs/2510.26495)
- 也可以扩展到 [BIRD-Interact](https://bird-interact.github.io/)
- 技术上仍然属于 AI DB agent，而不是退回传统 text-to-SQL
- 难度适中，更容易先做出结果

这一阶段适合研究的技术点包括：

- 多轮 intent tracking
- 上下文压缩与 schema grounding
- 中间结果驱动的 query revision
- verifier / self-correction
- interaction policy 与 stopping strategy

### 第二步：再升级到事务型状态变更

在第一步建立起稳定的交互式 DB agent 能力后，再把问题升级为：

**如何将自然语言数据意图编译为可验证、可回滚的事务型状态变更？**

这一步才真正进入：

- 写操作
- transaction boundary
- post-condition correctness
- rollback / repair
- policy-aware execution

也就是说：

- **第一步解决“能不能在现有 benchmark 上把交互式数据库 agent 做稳”**
- **第二步解决“能不能把 agent 从查询推进到事务型状态变更”**

这种两步路线更符合研究推进节奏，也更容易形成连续产出。

---

## 当前建议

因此，如果你现在就要定一个**可以马上开始做**的问题，我建议不要直接把题目写成完整的事务型状态变更，而是写成：

### 当前可做的问题

**如何提升 AI DB agent 在动态多轮数据库交互中的正确性与稳定性？**

### 中长期目标问题

**如何将自然语言数据意图编译为跨数据库环境、可验证、可回滚的事务型状态变更？**

这样写的好处是：

- 当前问题能直接对接现有 benchmark
- 长期问题仍然保留足够的前沿性
- 研究路径清晰，不会显得“大跃进”

---

## 一手参考资料

- BIRD, NeurIPS 2023: [arXiv:2305.03111](https://arxiv.org/abs/2305.03111)
- Spider 2.0, ICLR 2025 Oral: [arXiv:2411.07763](https://arxiv.org/abs/2411.07763)
- Spider 2.0 Official Benchmark: [spider2-sql.github.io](https://spider2-sql.github.io/)
- LiveSQLBench Official Site: [livesqlbench.ai](https://livesqlbench.ai/)
- DySQL-Bench: [arXiv:2510.26495](https://arxiv.org/abs/2510.26495)
- BIRD-Interact Official Site, ICLR 2026 Oral: [bird-interact.github.io](https://bird-interact.github.io/)
- BridgeScope, CIDR 2026: [vldb.org/cidrdb/2026/bridgescope-a-universal-toolkit-for-bridging-large-language-models-and-databases.html](https://www.vldb.org/cidrdb/2026/bridgescope-a-universal-toolkit-for-bridging-large-language-models-and-databases.html)
- Supporting Our AI Overlords, CIDR 2026: [vldb.org/cidrdb/2026/supporting-our-ai-overlords-redesigning-data-systems-to-be-agent-first.html](https://www.vldb.org/cidrdb/2026/supporting-our-ai-overlords-redesigning-data-systems-to-be-agent-first.html)
- LLM Query Rewrite Verification, CIDR 2026: [vldb.org/cidrdb/2026/leveraging-query-optimizers-to-verify-the-soundness-of-llm-based-query-rewrites-for-real-world-workloads.html](https://www.vldb.org/cidrdb/2026/leveraging-query-optimizers-to-verify-the-soundness-of-llm-based-query-rewrites-for-real-world-workloads.html)
