# AI DB Agent 研究问题调研报告

## 1. 引言：从 Text-to-SQL 到 Text-to-Transaction

如果只把 AI DB agent 理解成 `text-to-SQL`，这个问题已经偏旧了。2025-2026 年的新趋势表明，数据库智能体面对的任务正在从“生成一条查询语句”升级为“完成一个真实的数据工作流”：不仅要查，还要理解 schema、调用多步工具、修改数据、执行事务、验证结果，并在失败时补偿或回滚。

这也是为什么 `text2CRUD` 虽然是一个直观起点，但还不够作为 2026 年以后的研究问题。`CRUD` 更像单步接口翻译，而真实的 AI DB agent 更接近：

**text -> query/update/transaction/workflow**

进一步说，最值得研究的对象不是“自然语言生成 SQL”，而是：

**自然语言数据意图如何被编译为可验证、可回滚的事务型状态变更。**

---

## 2. 为什么 AI DB Agent 会在 2026 年及以后持续受关注

### 2.1 Benchmark 已经把问题从“问答”推进到“真实数据工作流”

[Spider 2.0](https://spider2-sql.github.io/) 官方站点明确指出，它不再是传统的单条 SQL 基准，而是面向真实企业环境的 workflow benchmark：包含 632 个任务、多个真实数据库与数据仓库环境，单任务可能涉及多轮查询、文件操作、脚本执行以及跨系统上下文。官方描述还强调，发布时先进模型在 Spider 2.0 上的表现远低于在 Spider 1.0 上的表现，这说明传统 `text-to-SQL` 能力并不能自动迁移到真实企业数据环境。

相关研究也在沿着“agent 化”方向推进。[ReFoRCE](https://arxiv.org/abs/2502.15742) 直接把 Spider 2.0 定位为面向现实数据库工程任务的 benchmark，并展示了 schema 压缩、表压缩、SQL 自我修正和投票式选择等 agentic 机制。[Bloomberg 的 PExA](https://www.bloomberg.com/company/stories/bloomberg-ai-researchers-advance-text-to-sql-accuracy-with-multi-agent-pexa-framework/) 则将多 agent planning 引入 Spider 2.0-Snow，说明数据库任务已经不再被看作一次性生成问题，而是规划与执行问题。

更重要的是，benchmark 还在继续向数据工程场景外扩。[JetBrains Databao 在 2026 年 2 月的 Spider 2.0-DBT 总结](https://blog.jetbrains.com/databao/2026/02/1-on-spider-2-0dbt-benchmark-how-databao-agent-did-it/) 强调，任务已扩展到 dbt 仓库：agent 需要阅读代码库、理解模型依赖、定位错误、修改模型并运行验证。这已经明显超出经典 SQL 生成范畴。

### 2.2 工业界已经开始把“数据 agent”做成产品能力

工业产品信号也很明确。[Microsoft 的 Dataverse Data Agent Architecture（2025-06-16）](https://www.microsoft.com/en-us/power-platform/blog/2025/06/16/data-agent-architecture-powered-by-microsoft-dataverse/) 提到，数据 agent 不只是查询数据，还可以在 schema 校验和权限控制下执行 create、update 等操作，并把 human-in-the-loop、RBAC、审计日志纳入架构。对应的 [Dataverse knowledge in Copilot agents](https://learn.microsoft.com/en-us/power-platform/release-plan/2025wave1/data-platform/dataverse-table-data-as-knowledge-copilot-agents) 则说明企业数据已经被正式视为 agent 的 grounding substrate。

数据库厂商也开始把 agent workload 当作一类原生场景。[Oracle AI Database 26ai 的官方博客](https://blogs.oracle.com/database/post/introducing-oracle-ai-database-26ai) 直接提出“agents are first-class citizens”，并把 agentic workflows、MCP server、in-database AI tools、SQL Firewall、细粒度行列控制放在同一产品叙事中。这说明数据库不再只是 agent 的后端存储，而正在成为 agent 的执行环境和安全边界。

### 2.3 数据库社区已经开始把“agent-first”当作系统研究问题

如果只是产品宣传，还不能说明它会成为稳定研究方向；但数据库研究社区也已经开始转向这一主题。[CIDR 2026 论文《Supporting Our AI Overlords: Redesigning Data Systems to be Agent-First》](https://www.vldb.org/cidrdb/2026/supporting-our-ai-overlords-redesigning-data-systems-to-be-agent-first.html) 明确提出，未来主导数据系统工作负载的可能是 agentic workloads，而不是人类 analyst。论文把核心挑战归纳为规模、异构性、冗余和可引导性，并提出需要新的 query interface、query processing technique 和 agentic memory store。

同时，[CIDR 2026 Program](https://www.cidrdb.org/cidr2026/program.html) 也已经把 “LLMs for Databases” 单独列为专题讨论。这说明 AI DB agent 不只是应用问题，也正在成为 data systems 的正式研究议题。

---

## 3. 相关工作可以分成三条主线

### 3.1 Text-to-SQL / Text-to-DB Access

这是最成熟的一条线，目标是把自然语言转成 SQL 或结构化查询。它的重要性仍然存在，但局限也越来越明显：大多数工作偏重读操作、单轮生成、语法与执行准确率，而弱化了事务性、多步交互和写操作风险。

### 3.2 Verifier-Backed / Safe DB Agents

第二条线开始关注 agent 的 correctness 与 safety：模型不应只是“能生成”，还必须“能被验证”。这条线会涉及 schema validation、policy checking、post-condition verification、human approval、rollback / repair 等机制。它更接近企业真实落地。

### 3.3 Agent-First Data Systems

第三条线把问题进一步上提：不是“怎么让 agent 用数据库”，而是“数据库应该如何为 agent workload 重新设计接口、内存、调度和执行机制”。这条线更偏 DBMS 和 infra，和 CIDR 2026 的议程最一致。

---

## 4. 当前研究空白

结合上述趋势，可以看到 2026 年以后最关键的 gap 不在于“模型会不会写 SQL”，而在于下面四个空缺：

1. **从读到写的空缺**  
现有工作大量聚焦查询，缺少对 update、insert、delete、stored procedure、跨表修改和事务边界的系统研究。

2. **从单步到多步的空缺**  
真实 DB agent 往往需要 schema 探索、计划生成、执行、结果检查、补救重试，而不是一次性生成一条语句。

3. **从语法正确到语义正确的空缺**  
今天很多 benchmark 仍以 execution accuracy 为主，但这并不等价于“系统状态达成了用户真正想要的结果”。对写操作来说，更重要的是 post-condition 是否满足。

4. **从接口翻译到事务型状态变更的空缺**  
`text2CRUD` 仍然太弱，因为它没有显式表达事务、一致性、失败恢复和补偿语义。未来更值得研究的是 `text2transactional state transition`。

---

## 5. 三个候选 Research Question 对比

| 候选 | 核心问题 | 优点 | 风险 | 2026+价值 |
| --- | --- | --- | --- | --- |
| 候选 1（主推） | 如何将自然语言数据意图编译为跨数据库环境、可验证、可回滚的事务型状态变更？ | 最贴近 `text2CRUD / text2事务型任务`，同时自然吸收 verifier、rollback、safety | 需要同时连接 NLP、DB、agent execution，系统边界较宽 | 强，直接覆盖 query + update + transaction |
| 候选 2 | 如何构建 verifier-backed AI DB agents，使其能够在复杂企业数据环境中安全执行多步查询、更新与数据工作流？ | 更强调 safety、critic、policy、human-in-the-loop，工业相关性强 | 容易写成 agent safety 报告，而弱化数据库本体 | 强，适合企业级落地方向 |
| 候选 3 | 数据库系统需要怎样的 agent-first execution 与 memory interface，才能原生支持高频 speculative AI agent workloads？ | 最前沿、最偏 data systems，与 CIDR 2026 直接对齐 | 容易偏 DBMS 基础设施，离你原始 `text2事务型任务` 直觉较远 | 强，适合系统/数据库方向深挖 |

这三者中，**候选 1 最值得作为主问题**。原因是它既保留了你最初的 `text2CRUD` 直觉，又把问题升级到了 2026 年以后更合理的抽象层：不是单步 CRUD，而是 **transactional state transition**。

---

## 6. 主推问题与初步技术路线

### 6.1 主推问题

**如何将自然语言数据意图编译为跨数据库环境、可验证、可回滚的事务型状态变更？**

这个问题的核心不是“生成 SQL”，而是把自然语言意图映射成一个完整的执行闭环：

`planner -> typed intent/action IR -> verifier -> execution -> post-condition check -> rollback/repair`

### 6.2 为什么这个问题最有价值

它同时连接了未来 AI DB agent 最重要的五件事：

- `跨数据库环境`：不能只对单一 schema 和单一 dialect 有效
- `typed IR`：不能让模型直接输出不可控 SQL/脚本
- `verification`：执行前后都要有程序化验收
- `transaction`：写操作必须具备边界、一致性和失败语义
- `rollback/repair`：当 agent 做错时，系统要能恢复

### 6.3 适合的评估方式

如果将来做这个题目，评价指标不应只看 query accuracy，而应至少包括：

- 查询任务成功率
- 更新/插入/删除任务成功率
- 事务级 post-condition 满足率
- 失败后的 rollback 正确率
- policy violation / unsafe action rate
- 跨环境迁移能力，例如 PostgreSQL、SQLite、Snowflake、Dataverse 或 dbt workflow

---

## 7. 对当前 demo 的启发

当前仓库里的 demo 不是 AI DB agent 本身，但它提供了一个有价值的方法启发：**自然语言目标不应该直接落到最终状态变更，而应该先经过计划、校验、执行和回滚链路。**

因此，这个 demo 最适合在报告中被定位为：

**一个较低风险、较小状态空间中的事务型 agent 原型启发。**

它启发的是 `plan -> verify -> rollback` 的方法，而不是数据库场景本身。

---

## 8. 结论与最终推荐

综合 benchmark、工业与数据库系统社区三方面信号，可以得出一个清晰结论：

2026 年及以后，AI DB agent 最值得研究的方向，不再是狭义的 `text-to-SQL`，也不应停留在单步 `text2CRUD`，而应升级为：

**自然语言到可验证事务型状态变更。**

因此，本报告最终推荐的主 research question 为：

### 中文版

**如何将自然语言数据意图编译为跨数据库环境、可验证、可回滚的事务型状态变更？**

### 英文版

**How can natural-language data intents be compiled into cross-database, verifiable, recoverable transactional state transitions?**

这个表述的优点是：

- 不退化成单纯 `text-to-SQL`
- 能覆盖 `query + update + transaction + workflow`
- 能自然吸收 verifier、policy、rollback、agent safety
- 同时对齐 AI agent、enterprise data systems 和 DBMS 三条 2026+ 主线

---

## 参考资料

1. [Spider 2.0 Official Site](https://spider2-sql.github.io/)
2. [ReFoRCE: A Text-to-SQL Agent with Self-Refinement, Schema Compression, and Voting](https://arxiv.org/abs/2502.15742)
3. [Bloomberg: PExA multi-agent framework on Spider 2.0](https://www.bloomberg.com/company/stories/bloomberg-ai-researchers-advance-text-to-sql-accuracy-with-multi-agent-pexa-framework/)
4. [JetBrains Databao: #1 on Spider 2.0-DBT Benchmark](https://blog.jetbrains.com/databao/2026/02/1-on-spider-2-0dbt-benchmark-how-databao-agent-did-it/)
5. [CIDR 2026: Supporting Our AI Overlords: Redesigning Data Systems to be Agent-First](https://www.vldb.org/cidrdb/2026/supporting-our-ai-overlords-redesigning-data-systems-to-be-agent-first.html)
6. [CIDR 2026 Program](https://www.cidrdb.org/cidr2026/program.html)
7. [Microsoft Dataverse Data Agent Architecture](https://www.microsoft.com/en-us/power-platform/blog/2025/06/16/data-agent-architecture-powered-by-microsoft-dataverse/)
8. [Dataverse table data as knowledge in Copilot agents](https://learn.microsoft.com/en-us/power-platform/release-plan/2025wave1/data-platform/dataverse-table-data-as-knowledge-copilot-agents)
9. [Oracle: Introducing Oracle AI Database 26ai](https://blogs.oracle.com/database/post/introducing-oracle-ai-database-26ai)
