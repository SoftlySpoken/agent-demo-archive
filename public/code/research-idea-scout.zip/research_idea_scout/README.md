# Research-Idea-Scout
### An agent skill for turning a research topic into an review paper project

> Give it a topic.
> It gives you a paper workspace, a plan, tracked issues, verified references, and eventually a compiled PDF.
> In other words: less "please write something smart," more "let's run an actual workflow."

## What This Is

`research-idea-scout` is a `.codex` skill for building **ML/AI review papers** in an **IEEEtran two-column LaTeX format**.

It is not just a fancy prompt.
It is a structured, issue-driven workflow that helps an agent go from:

- a research topic,
- to a scoped plan,
- to tracked writing tasks,
- to verified citations,
- to a complete LaTeX project,
- to a compiled review paper PDF.

The workflow is designed for **survey/review writing**, with an emphasis on:
- auditable intermediate artifacts,
- citation verification,
- reproducible paper structure,
- and fewer "the model improvised everything and now nobody knows what happened" moments.

## What’s Included

This repo contains:

- The main skill definition for `research-idea-scout`
- Helper scripts for scaffolding, planning, validation, citation handling, and compilation
- Templates for LaTeX paper projects
- Example outputs showing what the workflow can produce
- Supporting notes and references used by the skill system

In practice, the skill produces artifacts such as:

- `main.tex`
- `ref.bib`
- `plan/<timestamp>-<slug>.md`
- `issues/<timestamp>-<slug>.csv`
- `notes/literature-notes.md`
- `notes/arxiv-registry.sqlite3`
- `main.pdf`

## How the Workflow Works

The skill follows a gated workflow rather than jumping straight into prose.

### Stage 1: Plan First, Write Later

The agent starts with a topic and does a lightweight discovery pass:
- identify key papers,
- sketch an outline,
- suggest candidate titles,
- prepare a project scaffold,
- and generate a plan file.

At this stage, the paper is **not supposed to contain full prose yet**.
The goal is to define the scope before the agent starts confidently writing paragraphs it may later regret.

### Stage 2: Approval and Issue Creation

Once the scope and outline are confirmed, the workflow generates an issues CSV.

This issues file acts as the execution contract:
- what needs to be researched,
- what needs to be written,
- what must be verified,
- and what remains for QA.

Instead of "the agent writes the paper somehow," the work becomes a tracked sequence of tasks.

### Stage 3: Per-Issue Writing Loop

For each writing issue, the agent:
- researches section-specific papers,
- writes the relevant section,
- verifies citations before adding them,
- updates issue status,
- and recompiles the paper as needed.

That means the workflow is not just producing text.
It is producing text with receipts.

### Stage 4: QA and Compilation

After writing is done, the workflow performs final refinement and QA:
- citation checks,
- issue completion checks,
- LaTeX compilation,
- and final PDF generation.

The intended result is a paper project that is not only readable, but also inspectable.

## Quick Demo

A simple way to demonstrate the workflow is with two prompts.

### Prompt 1

```text
write a review article for arxiv that is about SOTA generative image models
```

After this, the agent typically:
- explores the topic,
- drafts a structure,
- proposes several titles,
- and creates a `plan/` markdown file.

### Prompt 2

```text
I will let you choose the best title and with the topics and inclusion of material that you see the best fit
```

With that approval, the workflow proceeds and builds out a full paper project.

The point of the demo is not that the second prompt is clever.
The point is that the system behind it already knows how to scaffold, track, validate, and compile.

## Why This Skill Exists

Because "write me a paper" is easy to ask and very hard to do well.

Large models are good at sounding fluent.
They are less good at:
- respecting scope boundaries,
- keeping long workflows coherent,
- managing citations carefully,
- and maintaining a stable paper structure across many steps.

`research-idea-scout` exists to fix that by moving as much discipline as possible into:
- structured skill instructions,
- helper scripts,
- templates,
- and explicit intermediate artifacts.

So instead of hoping the agent stays organized, the workflow gives it a system where organization is the default.

## Environment Requirements

You will need a working LaTeX setup, for example:

- `pdflatex` + `bibtex`, or
- `latexmk`

The helper scripts also expect a normal Python environment.

In short:
- Python for workflow scripts
- LaTeX for compilation
- a browser/search-capable agent for citation verification

## Example Output

This repository includes example generated outputs, including compiled PDFs and intermediate project files.

These examples are useful if you want to see what the workflow looks like after it has already done its job:
- scoped plan,
- tracked issues,
- bibliography,
- LaTeX source,
- and final compiled paper.

## In One Sentence

`research-idea-scout` is an agent skill for producing **structured, citation-aware, IEEEtran-based ML/AI review paper projects** without relying on pure prompt magic.

Or, more bluntly:

It turns "please write a survey" into something closer to an actual engineering process.
