---
mode: paper-plan
topic: SOTA vector quantization techniques for modern machine learning and generative modeling
timestamp: 2026-03-11_10-27-59
slug: vector-quantization-techniques-review
created_at: "2026-03-11T10:27:59+08:00"
complexity: medium
latex_available: true
---

# Paper Plan: SOTA vector quantization techniques for modern machine learning and generative modeling

**Selected working title:** State-of-the-Art Vector Quantization for Modern Machine Learning: From Product Quantization to Neural Codebooks

## Goal
- Produce an arXiv review paper on modern vector quantization with a bridge from classical quantization/search methods to neural codebooks used in generative modeling and compression.
- Target 60-80 verified citations, with the majority from 2022-2026 where possible.
- Include at least 5 visualizations spanning taxonomy, timeline, design tradeoffs, and benchmarks.

## Scope
- In: classical vector quantization foundations, product/residual/additive quantization, VQ-VAE lineage, residual/grouped quantizers, tokenizer design for image generation, neural audio/speech codecs, evaluation practices, and open problems.
- Out: non-quantization tokenizers based purely on continuous latents, unrelated compression theory, exhaustive hardware implementation detail, and new experiments.

## Kickoff Gate (must be confirmed before writing)
- **STOP**: Do not write prose into `main.tex` until this gate is confirmed and the issues CSV exists.
- [x] User confirmed scope + outline in chat
- Venue/template: IEEEtran (arXiv)
- Target length: 6-10 pages of main text (references excluded)
- "Latest" definition: as-of date = 2026-03-11
- Scope boundaries:
  - In-scope emphasis: methods that learn or optimize discrete codebooks for representation, retrieval, generation, or compression.
  - Proposed balance: 25\% classical foundations, 45\% neural/generative methods, 20\% codec/compression applications, 10\% evaluation and open problems.
  - Boundary to confirm: include ANN-search-centric PQ/RVQ foundations as the historical grounding, but keep the main emphasis on modern ML/neural VQ.

## Clarification Q&A (record answers)
| Question | Answer |
|---|---|
| What venue + page limit should we target? | Chosen: arXiv with IEEEtran, 8-10 pages main text |
| Which subtopics MUST be covered? | Chosen: PQ/RVQ foundations, VQ-VAE/VQGAN/RQ-VAE, FSQ/SimVQ-style recent methods, neural audio codecs |
| What are the main emphasis areas? | Chosen: representation quality, codebook efficiency, and tokenizer impact on generative performance |
| Any required datasets/baselines? | Chosen: ANN retrieval benchmarks, ImageNet/OpenImages-style tokenization reports, LibriSpeech and audio-codec evaluations |
| Expected figures/tables (min 5 types): any must-haves? | Chosen: taxonomy figure, historical timeline, method comparison table, codebook-design matrix, benchmark/metric table |

## Confirmed Outline (edit to match the user-approved outline)
1. Introduction and Scope
   - Define vector quantization across retrieval, compression, and representation learning
   - State SOTA criteria and the 2026-03-11 cutoff
   - Explain why neural tokenizers revived interest in VQ
2. Classical Foundations and Taxonomy
   - Flat VQ, product quantization, optimized PQ, residual/additive quantization
   - Memory-distance tradeoffs for large-scale search
   - Historical bridge to learned discrete codebooks
3. Neural Vector Quantization Mechanisms
   - VQ objectives, commitment/codebook losses, EMA updates, collapse handling
   - Multi-stage and grouped residual quantizers
   - Scalarized or simplified codebook parameterizations
4. Vector Quantization for Generative Modeling and Tokenization
   - VQ-VAE, VQ-VAE-2, VQGAN, RQ-VAE, modern visual tokenizers
   - Tokenizer quality as a bottleneck for autoregressive and diffusion systems
   - Tradeoffs between fidelity, token count, and decoding cost
5. Vector Quantization for Neural Compression and Audio Codecs
   - SoundStream, Encodec, and RVQ-based codec designs
   - Rate scalability and semantic token reuse
   - Cross-pollination between compression tokenizers and generative models
6. Evaluation, Benchmarks, and Practical Tradeoffs
   - Distortion, rate, perplexity, usage entropy, retrieval accuracy, downstream generation quality
   - Benchmark fragmentation across ANN, image tokenization, and audio coding
   - Practical recommendations for fair comparison
7. Open Problems and Outlook
   - Collapse-resistant training, adaptive codebooks, multimodal shared token spaces
   - Missing theory for tokenizer quality and transfer
   - Opportunities for unified evaluation

## Plan Notes
### Keywords used for discovery
- vector quantization, product quantization, residual vector quantization, additive quantization
- discrete representation learning, codebook collapse, EMA codebook updates
- VQ-VAE, VQ-VAE-2, VQGAN, RQ-VAE, residual quantizer
- finite scalar quantization, SimVQ, lookup-free quantization, visual tokenizer
- neural audio codec, SoundStream, Encodec, residual vector quantization

### Research snapshot (anchor papers; 12)
Classical foundations:
- Jégou et al., "Product Quantization for Nearest Neighbor Search" (2011)
- Ge et al., "Optimized Product Quantization" (CVPR 2013)
- Liu et al., "Approximate Nearest Neighbor Search by Residual Vector Quantization" (Sensors 2010)

Neural VQ foundations and generative tokenizers:
- van den Oord et al., "Neural Discrete Representation Learning" (2017, VQ-VAE)
- Razavi et al., "Generating Diverse High-Fidelity Images with VQ-VAE-2" (2019)
- Esser et al., "Taming Transformers for High-Resolution Image Synthesis" (2021, VQGAN)
- Lee et al., "Autoregressive Image Generation using Residual Quantization" (2022, RQ-VAE)
- Mentzer et al., "Finite Scalar Quantization: VQ-VAE Made Simple" (2024)
- Yu et al., "Language Model Beats Diffusion -- Tokenizer is Key to Visual Generation" (2024)
- Zhu et al., "Restructuring Vector Quantization with the Multivariate Information Bottleneck" (2024, SimVQ)

Compression and codec applications:
- Zeghidour et al., "SoundStream: An End-to-End Neural Audio Codec" (2021)
- Defossez et al., "High Fidelity Neural Audio Compression" (2022, Encodec)

Additional likely follow-ups after approval:
- additive/residual quantization variants for extreme compression
- lookup-free quantization and binary/spherical quantizers
- grouped residual quantization and codebook sharing methods
- tokenizer benchmarking papers released after mid-2024

### Candidate titles proposed (pick 1)
- State-of-the-Art Vector Quantization for Modern Machine Learning: From Product Quantization to Neural Codebooks
- Vector Quantization in the Deep Learning Era: Residual Codebooks, Tokenizers, and Neural Compression
- From Product Quantization to VQGAN and FSQ: A Review of Modern Vector Quantization Techniques
- Modern Vector Quantization for Retrieval, Generative Modeling, and Compression

### Sections/subsections plan
- Section 2 (Foundations): concise mathematical framing plus one taxonomy table for flat/PQ/RVQ/additive variants
- Section 3 (Neural mechanisms): loss design, codebook updates, collapse mitigation, residual/grouped/scalarized variants
- Section 4 (Generative tokenization): image tokenizers, tokenizer-model co-design, recent evidence that tokenizer quality drives frontier performance
- Section 5 (Compression/codecs): RVQ in audio codecs, semantic-acoustic token separation, scalability tradeoffs
- Section 6 (Evaluation): unify metrics across retrieval, reconstruction, and downstream generation; call out apples-to-oranges comparisons
- Section 7 (Outlook): unresolved theory, multimodal token spaces, evaluation gaps

### Visualization plan (types + placement)
- Fig. 1 (Sec. 2): taxonomy diagram from classical VQ to neural codebooks
- Fig. 2 (Sec. 4): timeline from VQ-VAE to recent tokenizer simplifications and frontier systems
- Tab. 1 (Secs. 2-4): technique comparison across code assignment, codebook structure, strengths, failure modes
- Fig. 3 (Sec. 3): codebook learning pipeline showing encoder, quantizer, decoder, and residual stages
- Fig. 4 (Sec. 5): RVQ-based neural codec stack with bitrate ladder
- Tab. 2 (Sec. 6): evaluation matrix covering retrieval, reconstruction, and downstream-generation metrics

## Issue CSV
- Path: issues/2026-03-11_10-27-59-vector-quantization-techniques-review.csv
- Must share the same timestamp/slug as this plan
- This CSV is the execution contract: update issue status as you write and QA
- Issues may be added/split/inserted during execution; re-validate after edits and keep going until all issues are `DONE`/`SKIP` when feasible.
