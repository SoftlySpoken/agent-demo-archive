# Literature Notes: SOTA vector quantization techniques for modern machine learning and generative modeling

This file is **optional**. Use it to keep a lightweight evidence trail for the papers you cite in `ref.bib`.
It helps prevent ``citation-only'' writing where claims drift away from what the cited work actually supports.

## Rules
- Keep each entry short (aim: 3--6 bullets).
- Every entry should answer: *what is the contribution* and *why are we citing it*.
- If a key claim is important, record the exact metric/dataset/setting.
- If the paper is not fully verifiable (paywall, missing PDF), mark **TODO** and do not rely on it for strong claims.
- If helpful, keep a very short abstract excerpt (1--3 sentences) to avoid re-searching.

## Entry template (copy/paste)

### <citationKey> --- <short title> (<year>)
- URL:
- Abstract (optional, 1--3 sentences max):
- One-sentence summary:
- Why we cite it (section + claim):
- Evidence (numbers / datasets / ablations):
- Limitations / caveats:
- Notes:

## Entries

<!-- Add entries below. -->

### jegou2011pq --- Product Quantization for Nearest Neighbor Search (2011)
- URL: https://pubmed.ncbi.nlm.nih.gov/21088323/
- One-sentence summary: Introduces product quantization for compact approximate nearest-neighbor search by factorizing the space into independently quantized subspaces.
- Why we cite it: Historical foundation for factorized codebooks and memory--accuracy tradeoffs.
- Evidence: Establishes asymmetric distance computation and strong compression for large-scale search.
- Limitations / caveats: Retrieval-centric; not a learned neural tokenizer.

### liu2010rvq --- Approximate Nearest Neighbor Search by Residual Vector Quantization (2010)
- URL: https://www.mdpi.com/1424-8220/10/12/11259
- One-sentence summary: Applies residual vector quantization to ANN search via stage-wise refinement of residual errors.
- Why we cite it: Historical basis for residual codebooks and multi-stage approximation.
- Evidence: Frames RVQ as sequential refinement and motivates later neural RVQ stacks.
- Limitations / caveats: Pre-deep-learning system assumptions.

### oord2017vqvae --- Neural Discrete Representation Learning (2017)
- URL: https://arxiv.org/abs/1711.00937
- One-sentence summary: Introduces VQ-VAE and the modern neural codebook bottleneck with straight-through training.
- Why we cite it: Foundation for learned discrete representation learning.
- Evidence: Encoder, nearest-code assignment, commitment loss, autoregressive prior interface.
- Limitations / caveats: Early method; later work improves fidelity and collapse behavior.

### esser2021taming --- Taming Transformers for High-Resolution Image Synthesis (2021)
- URL: https://arxiv.org/abs/2012.09841
- One-sentence summary: Combines perceptual and adversarial training with a VQ tokenizer to improve image-token quality.
- Why we cite it: Major transition point from neural VQ to practical visual tokenization.
- Evidence: High-resolution image synthesis through VQGAN plus transformer modeling.
- Limitations / caveats: More training complexity than plain VQ-VAE.

### lee2022rqvae --- Autoregressive Image Generation using Residual Quantization (2022)
- URL: https://arxiv.org/abs/2203.01941
- One-sentence summary: Uses residual learned quantizers for image tokenization and autoregressive generation.
- Why we cite it: Key evidence that residual quantization improves generation-friendly tokenizers.
- Evidence: Better fidelity/token efficiency tradeoff than single-stage codebooks.
- Limitations / caveats: Adds multi-stage complexity.

### mentzer2024fsq --- Finite Scalar Quantization: VQ-VAE Made Simple (2024)
- URL: https://arxiv.org/abs/2309.15505
- One-sentence summary: Replaces large learned codebooks with scalar quantization bins while retaining discrete bottlenecks.
- Why we cite it: Representative simplification trend in modern VQ.
- Evidence: Competitive neural tokenizer performance with much simpler quantizer machinery.
- Limitations / caveats: Scalar factorization may underspecify some correlations.

### yu2024tokenizer --- Language Model Beats Diffusion -- Tokenizer is Key to Visual Generation (2024)
- URL: https://arxiv.org/abs/2310.05737
- One-sentence summary: Argues that tokenizer quality is decisive for high-quality visual generation with language-model-style decoders.
- Why we cite it: Central support for the paper's emphasis on tokenizer quality as a bottleneck.
- Evidence: Strong generation results tied to improved visual tokenizer design.
- Limitations / caveats: Frontier-system evaluation is partly system-dependent.

### defossez2022encodec --- High Fidelity Neural Audio Compression (2022)
- URL: https://arxiv.org/abs/2210.13438
- One-sentence summary: Presents a strong RVQ-based neural audio codec across multiple operating points.
- Why we cite it: Evidence that residual quantization is practical beyond vision.
- Evidence: Reinforces bitrate ladders and system-level tradeoffs in neural codecs.
- Limitations / caveats: Audio-domain metrics do not directly transfer to visual tokenizers.
